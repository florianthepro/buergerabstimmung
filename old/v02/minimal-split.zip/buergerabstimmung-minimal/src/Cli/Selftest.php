<?php

// code: https://github.com/florianthepro/buergerabstimmung
// Prüft die Anwendung im Selbsttest.

declare(strict_types=1);

function cli_selftest(): int
{
    $tmpDir = sys_get_temp_dir() . '/buergerabstimmung-selftest-' . bin2hex(random_bytes(4));
    mkdir($tmpDir, 0700, true);
    $pass = 0;
    $fail = 0;
    $check = static function (string $description, bool $ok, string $note = '') use (&$pass, &$fail): void {
        if ($ok) {
            $pass++;
            echo "  ok  {$description}\n";
        } else {
            $fail++;
            echo "FAIL  {$description}" . ($note !== '' ? ': ' . $note : '') . "\n";
        }
    };
    SW::$pepper = bin2hex(random_bytes(32));
    SW::$dataDir = $tmpDir;
    if (card_supports_sodium()) {
        SW::$serverSign = sodium_crypto_sign_secretkey(sodium_crypto_sign_keypair());
    }
    $t0 = new DateTimeImmutable('2026-03-02 12:00:00', new DateTimeZone('Europe/Berlin'));
    Clock::setTestNow($t0);
    $warp = static function (string $modify) use (&$t0): void {
        $t0 = $t0->modify($modify);
        Clock::setTestNow($t0);
    };

    echo "== Grunddaten ==\n";
    cli_switch_db($tmpDir, 'base');
    $check('Kategorien angelegt', count(categories()) >= 20);
    $check('Keine vorbefüllten Themen', site_stats()['topics'] === 0);
    $check('System-Konto vorhanden', (int) SW::$db->val('SELECT COUNT(*) FROM users WHERE is_system = 1') === 1);

    echo "== Ausweis-Schlüssel & Zeitfenster ==\n";
    if (card_supports_sodium()) {
        $pair = sodium_crypto_sign_keypair();
        $card = ['secret' => sodium_crypto_sign_secretkey($pair), 'pk' => sodium_crypto_sign_publickey($pair)];
        $other = sodium_crypto_sign_keypair();
        $otherPk = sodium_crypto_sign_publickey($other);
    } else {
        $secret = random_bytes(32);
        $card = ['secret' => $secret, 'pk' => hash('sha256', 'pk|' . $secret, true)];
        $otherPk = hash('sha256', 'pk|' . random_bytes(32), true);
    }
    $sealed = card_seal($card, 'vote');
    $check('Umschlag öffnet mit richtigem öffentlichen Schlüssel', card_open($card['pk'], $sealed, 'vote') === true);
    $check('Fremder öffentlicher Schlüssel wird abgelehnt', card_open($otherPk, $sealed, 'vote') === false);
    $check('Falsche Aktion wird abgelehnt', card_open($card['pk'], $sealed, 'report') === false);
    $tSave = $t0;
    $warp('+11 minutes');
    $check('Alter Umschlag verfällt (TOTP-Zeitfenster)', card_open($card['pk'], $sealed, 'vote') === false);
    $check('Neuer Umschlag zu neuer Zeit ist anders und gültig',
        card_seal($card, 'vote') !== $sealed && card_open($card['pk'], card_seal($card, 'vote'), 'vote') === true);
    $t0 = $tSave;
    Clock::setTestNow($t0);
    $check('Identität = öffentlicher Schlüssel (kein Pseudonym)', card_identity($card) === bin2hex($card['pk']));

    echo "== Stimmen entkoppelt & 24h-Sperre ==\n";
    $vt1 = cli_add_users(1, 'vt')[0];
    $vtTopic = cli_make_topic($vt1, 'Thema für Stimmtests');
    vote_cast($vt1, $vtTopic, 'for');
    $check('Stimmen-Tabelle ohne Ausweis-Bezug (kein user_id)',
        SW::$db->val("SELECT COUNT(*) FROM pragma_table_info('votes') WHERE name = 'user_id'") == 0);
    $tag = vote_tag($vtTopic, user_pk($vt1));
    $check('Stimme unter HMAC-Marker gespeichert (nicht Klar-ID)',
        SW::$db->val('SELECT COUNT(*) FROM votes WHERE topic_id = ? AND voter_tag = ?', [$vtTopic, $tag]) == 1);
    vote_cast($vt1, $vtTopic, 'against');
    $check('Änderung innerhalb 24 h möglich', topic_user_vote($vtTopic, $vt1) === 'against');
    $warp('+25 hours');
    try {
        vote_cast($vt1, $vtTopic, 'for');
        $check('Änderung nach 24 h gesperrt', false);
    } catch (DomainException $e) {
        $check('Änderung nach 24 h gesperrt', $e->getMessage() === 'flash.vote_locked');
    }
    $warp('-25 hours');

    echo "== Themen-Ende (Datum/Anzahl) & Autor-Rechte ==\n";
    $au = cli_add_users(1, 'au')[0];
    $catId = (int) SW::$db->val('SELECT id FROM categories ORDER BY id LIMIT 1');
    $countTopic = topic_create($au, 'Thema endet bei 2 Stimmen', 'Ziel für den Anzahl-Test hier.', 'Begründung für den Anzahl-Test hier.', $catId, 'bund', null, 'count', null, 2);
    $c1 = cli_add_users(1, 'c1')[0];
    $c2 = cli_add_users(1, 'c2')[0];
    vote_cast($c1, $countTopic, 'for');
    $check('Thema bei Zielzahl noch offen (1/2)', SW::$db->val('SELECT status FROM topics WHERE id = ?', [$countTopic]) === 'active');
    vote_cast($c2, $countTopic, 'against');
    $check('Thema schließt bei Erreichen der Zielzahl (2/2)', SW::$db->val('SELECT status FROM topics WHERE id = ?', [$countTopic]) === 'closed');
    try {
        vote_cast($au, $countTopic, 'for');
        $check('Keine Stimme nach Schließung', false);
    } catch (DomainException $e) {
        $check('Keine Stimme nach Schließung', $e->getMessage() === 'flash.topic_not_votable');
    }
    $warp('+1 day');
    $dateTopic = topic_create($au, 'Thema endet gestern', 'Ziel für den Datum-Test hier.', 'Begründung für den Datum-Test hier.', $catId, 'bund', null, 'date', substr(Clock::nowStr(), 0, 10), null);
    $warp('+2 days');
    maintenance_tick();
    $check('Datumsende schließt Thema', SW::$db->val('SELECT status FROM topics WHERE id = ?', [$dateTopic]) === 'closed');
    $warp('-3 days');
    $au2 = cli_add_users(1, 'au2')[0];
    $ownTopic = cli_make_topic($au2, 'Uferpromenade in Buchholz sanieren');
    $check('Kein Bearbeiten mehr vorhanden',
        !function_exists('topic_update') && !function_exists('v_topic_edit') && !function_exists('h_topic_edit'));
    try {
        topic_archive($ownTopic, $c1);
        $check('Nicht-Autor kann nicht archivieren', false);
    } catch (DomainException $e) {
        $check('Nicht-Autor kann nicht archivieren', $e->getMessage() === 'flash.not_author');
    }
    vote_cast($c1, $ownTopic, 'for');
    try {
        topic_archive($ownTopic, $au2);
        $check('Abgestimmtes Thema bleibt dauerhaft bestehen', false);
    } catch (DomainException $e) {
        $check('Abgestimmtes Thema bleibt dauerhaft bestehen', $e->getMessage() === 'flash.topic_locked');
    }
    $check('Abgestimmtes Thema weiterhin aktiv',
        SW::$db->val('SELECT status FROM topics WHERE id = ?', [$ownTopic]) === 'active');
    $warp('+1 day');
    $freshTopic = cli_make_topic($au2, 'Thema ohne Stimmen zum Archivieren');
    topic_archive($freshTopic, $au2);
    $check('Thema ohne Stimmen wird archiviert, nicht gelöscht',
        SW::$db->val('SELECT status FROM topics WHERE id = ?', [$freshTopic]) === 'archived'
        && SW::$db->val('SELECT COUNT(*) FROM topics WHERE id = ?', [$freshTopic]) == 1);
    $check('Archiviertes Thema erscheint nicht in der Liste',
        !in_array($freshTopic, array_map(static function (array $r): int {
            return (int) $r['id'];
        }, topics_list([], 1, 50, null)['rows']), true));
    try {
        vote_cast($c1, $freshTopic, 'for');
        $check('Archiviertes Thema ist nicht wählbar', false);
    } catch (DomainException $e) {
        $check('Archiviertes Thema ist nicht wählbar', $e->getMessage() === 'flash.topic_not_votable');
    }
    try {
        topic_archive($freshTopic, $au2);
        $check('Archiviertes Thema kann nicht erneut archiviert werden', false);
    } catch (DomainException $e) {
        $check('Archiviertes Thema kann nicht erneut archiviert werden', $e->getMessage() === 'flash.not_author');
    }
    $warp('-1 day');
    $similar = topics_similar('Uferpromenade in Buchholz sanieren', null, 5);
    $check('Ähnliches Thema wird gefunden', $similar !== [] && (int) $similar[0]['id'] === $ownTopic);
    $check('Unähnlicher Titel liefert nichts',
        topics_similar('Vollkommen anderes Anliegen ohne Bezug', null, 5) === []);
    $check('Eigenes Thema wird bei der Suche ausgeblendet',
        topics_similar('Uferpromenade in Buchholz sanieren', $ownTopic, 5) === []);

    echo "== Profil: verschlüsselt an Public Key + Server-Signatur ==\n";
    if (card_supports_sodium()) {
        $pair = sodium_crypto_sign_keypair();
        $pkHex = bin2hex(sodium_crypto_sign_publickey($pair));
        SW::$db->run('INSERT INTO users (pseudonym_hash, lang, created_at) VALUES (?, ?, ?)', [$pkHex, 'de', Clock::nowStr()]);
        $pu = SW::$db->one('SELECT * FROM users WHERE pseudonym_hash = ?', [$pkHex]);
        $sealed = profile_sealed($pu);
        $check('Ausgeliefertes Profil enthält keinen Klartext-Schlüssel im Inhalt',
            strpos($sealed, 'buergerabstimmung_versiegeltes_profil') === 0);

        preg_match('/chiffre_b64: "([^"]+)"/', $sealed, $cm);
        preg_match('/server_signatur_b64: "([^"]+)"/', $sealed, $sm);
        $cipher = base64_decode($cm[1]);
        $sig = base64_decode($sm[1]);
        $serverPk = hex2bin(server_sign_pk_hex());
        $check('Server-Signatur bestätigt (keine Manipulation)',
            sodium_crypto_sign_verify_detached($sig, $cipher, $serverPk) === true);
        $check('Manipulierte Chiffre fällt bei Signaturprüfung durch',
            sodium_crypto_sign_verify_detached($sig, $cipher . 'x', $serverPk) === false);
        $curveSk = sodium_crypto_sign_ed25519_sk_to_curve25519(sodium_crypto_sign_secretkey($pair));
        $curvePk = sodium_crypto_sign_ed25519_pk_to_curve25519(sodium_crypto_sign_publickey($pair));
        $keypair = sodium_crypto_box_keypair_from_secretkey_and_publickey($curveSk, $curvePk);
        $plain = sodium_crypto_box_seal_open($cipher, $keypair);
        $check('Nur mit dem Ausweis-Schlüssel entschlüsselbar', is_string($plain) && strpos($plain, 'buergerabstimmung_profil') === 0);
    } else {
        $check('Profil-Versiegelung übersprungen (kein sodium)', true);
        $check('Profil-Versiegelung übersprungen (kein sodium)', true);
        $check('Profil-Versiegelung übersprungen (kein sodium)', true);
        $check('Profil-Versiegelung übersprungen (kein sodium)', true);
    }

    echo "== Meldegrund: Gesetzesverstoß ==\n";
    $check('Suche nach Schlagwort findet Volksverhetzung', isset(law_search('hetze')['stgb-130-1']));
    $check('Suche nach Paragraph findet § 185', isset(law_search('185')['stgb-185']));
    $check('Leere Suche liefert nichts', law_search('') === []);
    try {
        report_create(999999, 1, 'kein-gesetz');
        $check('Unbekanntes Gesetz abgelehnt', false);
    } catch (DomainException $e) {
        $check('Unbekanntes Gesetz abgelehnt', $e->getMessage() === 'flash.report_no_law');
    }

    echo "== Geltungsbereich (amtliche Auswahl) ==\n";
    $check('Deutschland', scope_decode('de') === ['bund', null]);
    $check('Bundesland', scope_decode('bl:Bayern') === ['bundesland', 'Bayern']);
    $check('Landkreis', scope_decode('kr:Bayern:Landkreis München') === ['landkreis', 'Landkreis München']);
    $check('Unbekanntes Gebiet abgelehnt', scope_decode('kr:Bayern:Atlantis') === null && scope_decode('bl:Atlantis') === null);
    $check('Gebietsliste vollständig geladen', count(SW_REGIONS) === 16 && array_sum(array_map('count', SW_REGIONS)) > 350);

    echo "== Themen: 1 pro Tag ==\n";
    $alice = cli_add_users(1, 'alice')[0];
    $topicId = cli_make_topic($alice, 'Testthema Nummer eins');
    $check('Erstes Thema angelegt', $topicId > 0);
    try {
        cli_make_topic($alice, 'Zweites Thema am selben Tag');
        $check('Zweites Thema am selben Tag abgelehnt', false);
    } catch (DomainException $e) {
        $check('Zweites Thema am selben Tag abgelehnt', $e->getMessage() === 'flash.topic_daily_limit');
    }
    $warp('+1 day');
    $check('Thema am Folgetag erlaubt', cli_make_topic($alice, 'Thema am nächsten Tag') > 0);

    echo "== Stimmen & Favoriten ==\n";
    $bob = cli_add_users(1, 'bob')[0];
    vote_cast($bob, $topicId, 'for');
    $check('Stimme dafür gespeichert', topic_user_vote($topicId, $bob) === 'for');
    vote_cast($bob, $topicId, 'against');
    $check('Stimme änderbar', topic_user_vote($topicId, $bob) === 'against');
    vote_cast($bob, $topicId, 'none');
    $check('Stimme zurückziehbar (neutral = keine Stimme)', topic_user_vote($topicId, $bob) === null);
    $slug = (string) SW::$db->val('SELECT slug FROM categories ORDER BY id LIMIT 1');
    $check('Favorit angelegt', fav_toggle($bob, 'category', $slug) === true);
    $check('Favorit entfernt', fav_toggle($bob, 'category', $slug) === false);
    $check('Gebiets-Favorit (Landkreis) gegen Liste geprüft', fav_toggle($bob, 'scope', 'landkreis:Ostalbkreis') === true);
    try {
        fav_toggle($bob, 'scope', 'landkreis:Entenhausen');
        $check('Erfundenes Gebiet abgelehnt', false);
    } catch (DomainException $e) {
        $check('Erfundenes Gebiet abgelehnt', true);
    }

    echo "== Jury-Größe (1 %-Regel) ==\n";
    cli_switch_db($tmpDir, 'big');
    $crowd = cli_add_users(600, 'crowd');
    $reporter600 = cli_add_users(1, 'rep')[0];
    $target = cli_make_topic($crowd[0], 'Zielthema für die große Jury');
    report_create($target, $reporter600, 'stgb-130-1');
    $bigReport = SW::$db->one('SELECT * FROM reports ORDER BY id DESC LIMIT 1');
    $check('Jury = 1 % bei 601 Nutzenden (aufgerundet)', (int) $bigReport['jury_size'] === (int) ceil(601 * 0.01));
    $check('Quorum = 0,5 % (mind. 3)', (int) $bigReport['quorum'] === max(3, (int) ceil(601 * 0.005)));

    echo "== Meldung & Jury: Ausschlüsse, Fristen, Karenz ==\n";
    cli_switch_db($tmpDir, 'jury');
    $users = cli_add_users(12, 'u');
    $tX = cli_make_topic($users[8], 'Gemeldetes Thema X');
    $tY = cli_make_topic($users[9], 'Gemeldetes Thema Y');
    $jurorsOf = static function (int $reportId): array {
        return array_map(static function (array $r): int {
            return (int) $r['user_id'];
        }, SW::$db->all('SELECT user_id FROM report_jurors WHERE report_id = ?', [$reportId]));
    };

    $r1 = report_create($tX, $users[0], 'stgb-86a-1');
    $j1 = $jurorsOf($r1);
    $check('Jury 1: 5 Sitze (Mindestgröße)', count($j1) === 5);
    $check('Melder und Autor nicht in der Jury', !in_array($users[0], $j1, true) && !in_array($users[8], $j1, true));
    $r1Row = SW::$db->one('SELECT * FROM reports WHERE id = ?', [$r1]);
    $check('Meldung wartet bis Mitternacht', $r1Row['status'] === 'pending');
    $check('Start zur nächsten Mitternacht (00:00 lokal)', $r1Row['voting_starts_at'] === Clock::nextLocalMidnightUtcStr());
    try {
        report_create($tX, $users[1], 'stgb-185');
        $check('Zweite Meldung zum selben Thema abgelehnt', false);
    } catch (DomainException $e) {
        $check('Zweite Meldung zum selben Thema abgelehnt', $e->getMessage() === 'flash.report_already_open');
    }
    $r2 = report_create($tY, $users[1], 'stgb-241-1');
    $j2 = $jurorsOf($r2);
    $check('Jury 2 disjunkt zu laufender Jury 1', array_intersect($j1, $j2) === []);
    $check('Kein Jury-Gate vor Abstimmungsstart', jury_pending_for($j1[0]) === null);

    $warp('+1 day');
    maintenance_tick();
    $check('Abstimmung um 00:00 gestartet', SW::$db->val('SELECT status FROM reports WHERE id = ?', [$r1]) === 'voting');
    $check('Jury-Gate nach Start aktiv', jury_pending_for($j1[0]) !== null);
    jury_cast($r1, $j1[0], 'confirm');
    jury_cast($r1, $j1[1], 'confirm');
    jury_cast($r1, $j1[2], 'neutral');
    maintenance_tick();
    $check('Keine Entscheidung vor Ablauf der 24 h', SW::$db->val('SELECT status FROM reports WHERE id = ?', [$r1]) === 'voting');
    try {
        jury_cast($r1, $j1[0], 'reject');
        $check('Doppelte Jury-Stimme abgelehnt', false);
    } catch (DomainException $e) {
        $check('Doppelte Jury-Stimme abgelehnt', $e->getMessage() === 'flash.jury_already_voted');
    }
    $warp('+25 hours');
    maintenance_tick();
    $r1Row = SW::$db->one('SELECT * FROM reports WHERE id = ?', [$r1]);
    $check('Entscheidung nach Frist + Quorum (2:0 bestätigt)', $r1Row['status'] === 'decided_removed');
    $check('Thema entfernt', SW::$db->val('SELECT status FROM topics WHERE id = ?', [$tX]) === 'removed');
    $expectedCooldown = Clock::addDaysStr((string) $r1Row['decided_at'], 3);
    $cooldowns = SW::$db->all(
        'SELECT jury_cooldown_until FROM users WHERE id IN (' . implode(',', array_fill(0, count($j1), '?')) . ')',
        $j1
    );
    $check('Karenz (3 Tage) für alle Jury-Mitglieder gesetzt', array_unique(array_column($cooldowns, 'jury_cooldown_until')) === [$expectedCooldown]);

    $tZ = cli_make_topic($j1[0], 'Gemeldetes Thema Z');
    $r3 = report_create($tZ, $j2[0], 'stgb-126a-1');
    $j3 = $jurorsOf($r3);
    $expectedJ3 = array_values(array_diff(array_map('intval', $users), $j1, $j2));
    sort($j3);
    sort($expectedJ3);
    $check('Karenz + laufende Jurys schließen korrekt aus (Restmenge = 2)', $j3 === $expectedJ3 && count($j3) === 2);

    $warp('+1 day');
    maintenance_tick();
    jury_cast($r3, $j3[0], 'reject');
    $warp('+25 hours');
    maintenance_tick();
    $check('Meldung läuft weiter, bis das Quorum erreicht ist', SW::$db->val('SELECT status FROM reports WHERE id = ?', [$r3]) === 'voting');
    jury_cast($r3, $j3[1], 'reject');
    $check('Entscheidung sofort bei Quorum nach Fristablauf (behalten)', SW::$db->val('SELECT status FROM reports WHERE id = ?', [$r3]) === 'decided_kept');
    $check('Thema bleibt bei Ablehnung bestehen', SW::$db->val('SELECT status FROM topics WHERE id = ?', [$tZ]) === 'active');

    $warp('+2 days');
    $tW = cli_make_topic($j2[2], 'Gemeldetes Thema W');
    $r4 = report_create($tW, $j2[1], 'stgb-240-1');
    $j4 = $jurorsOf($r4);
    sort($j1);
    sort($j4);
    $check('Nach 3 Tagen Karenz wieder losbar (Jury 4 = frühere Jury 1)', $j4 === $j1);

    echo "== Strenge im Normalmodus / Skip im Testmodus ==\n";
    if (card_supports_sodium()) {
        $pairA = sodium_crypto_sign_keypair();
        $cardA = ['secret' => sodium_crypto_sign_secretkey($pairA), 'pk' => sodium_crypto_sign_publickey($pairA)];
        $pairB = sodium_crypto_sign_keypair();
        $cardB = ['secret' => sodium_crypto_sign_secretkey($pairB), 'pk' => sodium_crypto_sign_publickey($pairB)];
        $userA = ['pseudonym_hash' => card_identity($cardA)];
        SW::$testMode = false;
        $check('Normalmodus: ohne Ausweis abgelehnt', card_confirm_ok($userA, null, 'confirm:/vote') === false);
        $check('Normalmodus: fremder Ausweis abgelehnt', card_confirm_ok($userA, $cardB, 'confirm:/vote') === false);
        $check('Normalmodus: eigener Ausweis bestätigt', card_confirm_ok($userA, $cardA, 'confirm:/vote') === true);
        SW::$testMode = true;
        $check('Testmodus: Ausweis-Aufforderung entfällt', card_confirm_ok($userA, null, 'confirm:/vote') === true);
        SW::$testMode = false;
    } else {
        for ($i = 0; $i < 5; $i++) {
            $check('Strenge-Prüfung übersprungen (kein sodium)', true);
        }
    }

    echo "== Allowlist autorisierter Ausweis-Schlüssel ==\n";
    @unlink(authorized_file());
    $check('Leere Allowlist weist alles ab', authorized_contains(str_repeat('a', 64)) === false);
    $goodPk = str_repeat('b', 64);
    authorized_add([$goodPk], 'test');
    $check('Autorisierter Schlüssel erkannt', authorized_contains($goodPk) === true);
    $check('Nicht autorisierter Schlüssel abgewiesen', authorized_contains(str_repeat('c', 64)) === false);
    $check('Doppeltes Hinzufügen ohne Duplikat', authorized_add([$goodPk], 'test') === 0);
    $check('Ungültiges Format wird ignoriert', authorized_add(['xyz'], 'test') === 0 && !authorized_contains('xyz'));

    echo "== Sortierung: größte Netto-Zustimmung oben ==\n";
    cli_switch_db($tmpDir, 'sortdb');
    $sa = cli_add_users(1, 'sa')[0];
    $catS = (int) SW::$db->val('SELECT id FROM categories ORDER BY id LIMIT 1');
    $lowNet = topic_create($sa, 'Radweg-Vorschlag mit knapper Mehrheit', 'Ziel des ersten Sortier-Themas hier.', 'Begründung des ersten Sortier-Themas hier.', $catS, 'bund', null, 'date', substr(Clock::addDaysStr(Clock::nowStr(), 30), 0, 10), null);
    $sb = cli_add_users(1, 'sb')[0];
    $highNet = topic_create($sb, 'Radweg-Vorschlag mit klarer Mehrheit', 'Ziel des zweiten Sortier-Themas hier.', 'Begründung des zweiten Sortier-Themas hier.', $catS, 'bund', null, 'date', substr(Clock::addDaysStr(Clock::nowStr(), 30), 0, 10), null);
    $sv = cli_add_users(6, 'sv');

    vote_cast($sv[0], $lowNet, 'for');
    vote_cast($sv[1], $lowNet, 'against');

    vote_cast($sv[2], $highNet, 'for');
    vote_cast($sv[3], $highNet, 'for');
    vote_cast($sv[4], $highNet, 'for');
    $listed = topics_list(['q' => 'Radweg-Vorschlag'], 1, 10, null);
    $check('Suchtreffer nach Netto-Zustimmung: höchste zuerst',
        $listed['rows'] !== [] && (int) $listed['rows'][0]['id'] === $highNet);

    echo "== Kontolöschung (DSGVO) ==\n";
    cli_switch_db($tmpDir, 'gdpr');
    $pairIds = cli_add_users(2, 'cd');
    $carol = $pairIds[0];
    $dave = $pairIds[1];
    $carolTopic = cli_make_topic($carol, 'Thema von Carol zum Löschen');
    $daveTopic = cli_make_topic($dave, 'Thema von Dave bleibt bestehen');
    vote_cast($carol, $daveTopic, 'for');
    fav_toggle($carol, 'scope', 'bundesland:Bayern');
    $carolTag = vote_tag($daveTopic, user_pk($carol));
    account_delete($carol);
    $check('Nutzer gelöscht', (int) SW::$db->val('SELECT COUNT(*) FROM users WHERE id = ?', [$carol]) === 0);
    $check('Stimme bleibt anonym erhalten (nicht mehr zuordenbar)',
        (int) SW::$db->val('SELECT COUNT(*) FROM votes WHERE topic_id = ? AND voter_tag = ?', [$daveTopic, $carolTag]) === 1);
    $check('Favoriten gelöscht', (int) SW::$db->val('SELECT COUNT(*) FROM favorites WHERE user_id = ?', [$carol]) === 0);
    $systemId = (int) SW::$db->val('SELECT id FROM users WHERE is_system = 1');
    $check('Thema entkoppelt (System-Konto)', (int) SW::$db->val('SELECT author_id FROM topics WHERE id = ?', [$carolTopic]) === $systemId);

    echo "== Themen-Ende: Datum, Zielwert, Kombination ==\n";
    cli_switch_db($tmpDir, 'endform');
    $readEnd = static function (array $post): ?array {
        $_POST = $post;
        $result = parse_topic_end();
        $_POST = [];
        return $result;
    };
    $soon = substr(Clock::addDaysStr(Clock::nowStr(), 5), 0, 10);
    $check('Nur Datum ergibt Modus "date"', $readEnd(['end_by_date' => '1', 'end_date' => $soon]) === ['date', $soon, null]);
    $check('Nur Stimmenzahl ergibt Modus "count"', $readEnd(['end_by_target' => '1', 'end_value' => '250', 'end_unit' => 'count']) === ['count', null, 250]);
    $check('Datum + Zielwert ergibt Modus "both"',
        $readEnd(['end_by_date' => '1', 'end_date' => $soon, 'end_by_target' => '1', 'end_value' => '80', 'end_unit' => 'count']) === ['both', $soon, 80]);
    $check('Ohne Auswahl kein gültiges Ende', $readEnd([]) === null);
    $check('Datum in der Vergangenheit abgelehnt', $readEnd(['end_by_date' => '1', 'end_date' => '2000-01-01']) === null);
    $check('Prozent über 100 abgelehnt', $readEnd(['end_by_target' => '1', 'end_value' => '120', 'end_unit' => 'percent']) === null);
    cli_add_users(200, 'pc');
    $pct = $readEnd(['end_by_target' => '1', 'end_value' => '10', 'end_unit' => 'percent']);
    $check('Prozent wird in Stimmenzahl umgerechnet', $pct !== null && $pct[2] === 20);
    $bothUser = cli_add_users(1, 'both')[0];
    $bothTopic = topic_create($bothUser, 'Thema mit Datum und Zielzahl', 'Ziel des Kombi-Tests hier.', 'Begründung des Kombi-Tests hier.', $catId, 'bund', null, 'both', $soon, 2);
    $bv = cli_add_users(2, 'bv');
    vote_cast($bv[0], $bothTopic, 'for');
    vote_cast($bv[1], $bothTopic, 'for');
    $check('Kombination: Zielzahl schließt vor dem Datum',
        SW::$db->val('SELECT status FROM topics WHERE id = ?', [$bothTopic]) === 'closed');
    $dateFirst = topic_create($bv[0], 'Thema schließt am Datum', 'Ziel des Datum-Kombi-Tests.', 'Begründung des Datum-Kombi-Tests.', $catId, 'bund', null, 'both', substr(Clock::nowStr(), 0, 10), 1000000);
    $warp('+2 days');
    maintenance_tick();
    $check('Kombination: Datum schließt vor der Zielzahl',
        SW::$db->val('SELECT status FROM topics WHERE id = ?', [$dateFirst]) === 'closed');
    $warp('-2 days');

    echo "== Testbetrieb: Zustand in der Datenbank, Ende löscht alles ==\n";
    cli_switch_db($tmpDir, 'testmode');
    SW::$testMode = null;
    $check('Testbetrieb ist im Auslieferungszustand aktiv', test_mode() === true);
    $tmUser = cli_add_users(1, 'tm')[0];
    $tmTopic = cli_make_topic($tmUser, 'Thema aus dem Testbetrieb');
    vote_cast(cli_add_users(1, 'tv')[0], $tmTopic, 'for');
    fav_toggle($tmUser, 'scope', 'bundesland:Bayern');
    test_mode_end();
    $check('Testbetrieb beendet', test_mode() === false);
    $check('Themen gelöscht', (int) SW::$db->val('SELECT COUNT(*) FROM topics') === 0);
    $check('Stimmen gelöscht', (int) SW::$db->val('SELECT COUNT(*) FROM votes') === 0);
    $check('Favoriten gelöscht', (int) SW::$db->val('SELECT COUNT(*) FROM favorites') === 0);
    $check('Konten gelöscht (System-Konto bleibt)',
        (int) SW::$db->val('SELECT COUNT(*) FROM users WHERE is_system = 0') === 0
        && (int) SW::$db->val('SELECT COUNT(*) FROM users WHERE is_system = 1') === 1);
    $check('Kategorien bleiben erhalten', count(categories()) >= 20);
    SW::$testMode = true;

    echo "== Einrichtung des Echtbetriebs ==\n";
    cli_switch_db($tmpDir, 'setup');
    SW::$testMode = null;
    @unlink(authorized_file());
    @unlink(test_keys_file());
    $base = ['eid_mode' => 'demo', 'eid_server_url' => '', 'eid_server_cert' => '', 'eid_server_key' => '',
             'eid_client_url' => 'http://127.0.0.1:24727/eID-Client', 'authorized_keys_url' => '', 'nect_start' => ''];
    $validate = static function (array $over) use ($base): array {
        [$errors] = setup_validate(array_merge($base, $over));
        return $errors;
    };
    $check('Leere Freigabeliste ohne Abgleich-Adresse abgelehnt',
        in_array('setup.err_list_empty', $validate([]), true));
    authorized_add([str_repeat('ab', 32)], 'selftest');
    $check('Freigabeliste mit Eintrag genügt', $validate([]) === []);
    $check('eID-Modus ohne Serveradresse abgelehnt',
        in_array('setup.err_server_missing', $validate(['eid_mode' => 'eid']), true));
    $check('Serveradresse ohne https abgelehnt',
        in_array('setup.err_https', $validate(['eid_server_url' => 'http://eid.example']), true));
    $check('Nicht lesbares Zertifikat abgelehnt',
        in_array('setup.err_file', $validate(['eid_server_cert' => '/kein/pfad/cert.pem']), true));
    $check('Gültige eID-Angaben angenommen',
        $validate(['eid_mode' => 'eid', 'eid_server_url' => 'https://eid.example/soap']) === []);
    $saved = array_merge($base, ['eid_mode' => 'eid', 'eid_server_url' => 'https://eid.example/soap',
                                 'nect_start' => 'https://nect.example/start']);
    $check('Einstellungen gespeichert', setup_save($saved));
    $loaded = setup_load();
    $check('Einstellungen unverändert gelesen',
        $loaded['eid_server_url'] === 'https://eid.example/soap' && $loaded['eid_mode'] === 'eid');
    setup_apply($loaded);
    $check('Einstellungen überschreiben die Vorgabe',
        (string) SW::$cfg['eid_server_url'] === 'https://eid.example/soap'
        && (string) SW::$cfg['eid_providers']['nect']['start'] === 'https://nect.example/start');
    $check('Nicht vorgesehene Schlüssel werden nicht übernommen',
        !array_key_exists('session_idle_minutes', setup_load()));
    $check('Unerreichbarer eID-Server meldet Fehlschlag',
        setup_probe(array_merge($base, ['eid_server_url' => 'https://127.0.0.1:1/soap'])) === false);
    $token = setup_token();
    $check('Einrichtungsschlüssel erzeugt und stabil', strlen($token) === 32 && $token === setup_token());
    @unlink(authorized_file());
    @unlink(test_keys_file());
    $realKey = str_repeat('cd', 32);
    $testKey = str_repeat('ef', 32);
    authorized_add([$realKey], 'issue-card');
    authorized_add([$testKey], 'test-login');
    test_key_add($testKey);
    $check('Testschlüssel zählen nicht als freigegebene Ausweise', authorized_count_stable() === 1);
    test_mode_end();
    $check('Testschlüssel beim Umschalten entfernt', !authorized_contains($testKey));
    $check('Echter Ausweis-Schlüssel bleibt erhalten', authorized_contains($realKey));
    SW::$cfg = SW_CONFIG;
    @unlink(setup_file());
    @unlink(setup_token_file());
    SW::$testMode = true;

    echo "== Sprachtabellen ==\n";
    $dupes = static function (string $const): array {
        $src = sw_sources();
        $start = strpos($src, 'const ' . $const . ' = [');
        $end = strpos($src, "\n];", $start);
        $body = substr($src, $start, $end - $start);
        preg_match_all("/^ {4}'([a-z0-9_.]+)' =>/m", $body, $m);
        $seen = [];
        $twice = [];
        foreach ($m[1] as $key) {
            if (isset($seen[$key])) {
                $twice[] = $key;
            }
            $seen[$key] = true;
        }
        return $twice;
    };
    $check('Keine doppelten Schlüssel in SW_DE', $dupes('SW_DE') === []);
    $check('Keine doppelten Schlüssel in SW_EN', $dupes('SW_EN') === []);
    $outside = static function (): string {
        $src = sw_sources();
        $out = '';
        $cursor = 0;
        foreach (['SW_DE', 'SW_EN'] as $const) {
            $start = strpos($src, 'const ' . $const . ' = [');
            $end = strpos($src, "\n];", $start) + 3;
            $out .= substr($src, $cursor, $start - $cursor);
            $cursor = $end;
        }
        return $out . substr($src, $cursor);
    };
    $body = $outside();
    $orphans = array_values(array_filter(array_keys(SW_DE), static function (string $key) use ($body): bool {
        return strpos($body, "'" . $key . "'") === false;
    }));
    $check('Keine verwaisten Textschlüssel', $orphans === [], implode(', ', $orphans));
    $missingEn = array_diff(array_keys(SW_DE), array_keys(SW_EN));
    $missingDe = array_diff(array_keys(SW_EN), array_keys(SW_DE));
    $check('Deutsch und Englisch decken dieselben Schlüssel ab',
        $missingEn === [] && $missingDe === []);
    $emptyVals = array_filter(SW_EN, static function ($v): bool {
        return trim((string) $v) === '';
    });
    $check('Keine leeren englischen Texte', $emptyVals === []);

    Clock::setTestNow(null);
    putenv('BUERGERABSTIMMUNG_DB');
    array_map('unlink', glob($tmpDir . '/*') ?: []);
    rmdir($tmpDir);
    printf("\nErgebnis: %d bestanden, %d fehlgeschlagen.\n", $pass, $fail);
    return $fail === 0 ? 0 : 1;
}
