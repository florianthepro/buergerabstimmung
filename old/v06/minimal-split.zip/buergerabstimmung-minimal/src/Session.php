<?php

// code: https://github.com/florianthepro/v2
// Verwaltet Sitzung, Meldungen, Einmal-Token und Ratenbegrenzung.

declare(strict_types=1);

function consent_given(): bool
{
    return (string) ($_COOKIE['sw_consent'] ?? '') === '1';
}

function consent_set(): void
{
    setcookie('sw_consent', '1', [
        'expires'  => time() + 31536000,
        'path'     => '/',
        'secure'   => sw_is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function consent_return(): string
{
    $to = query_str('to', 120);
    return preg_match('#^/(topic/\d{1,10}|auth|imprint|privacy)?$#', $to) === 1 && $to !== '' ? $to : '/';
}

function lang_from_browser(): string
{
    $raw = (string) ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '');
    $first = strtolower(substr(trim(explode(',', $raw)[0]), 0, 2));
    return in_array($first, (array) SW::$cfg['langs'], true) ? $first : (string) SW::$cfg['default_lang'];
}

function lang_valid(string $code): bool
{
    return in_array($code, (array) SW::$cfg['langs'], true);
}

function lang_stored(): string
{
    $value = (string) ($_COOKIE['sw_lang'] ?? '');
    return lang_valid($value) ? $value : '';
}

function lang_wanted(): string
{
    $value = query_str('lang', 5);
    return lang_valid($value) ? $value : '';
}

function lang_store(string $code): void
{
    if (!lang_valid($code)) {
        return;
    }
    setcookie('sw_lang', $code, [
        'expires'  => time() + 31536000,
        'path'     => '/',
        'secure'   => sw_is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function lang_active(): string
{
    $lang = lang_stored();
    if ($lang === '') {
        $lang = lang_wanted();
    }
    return $lang === '' ? lang_from_browser() : $lang;
}

function session_boot(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    if (!consent_given()) {
        $GLOBALS['_SESSION'] = [];
        return;
    }
    session_name('sw_session');
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'secure'   => sw_is_https(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
    $now = time();
    $idle = isset($_SESSION['last_activity'])
        && ($now - (int) $_SESSION['last_activity']) > (int) SW::$cfg['session_idle_minutes'] * 60;
    $expired = isset($_SESSION['auth_time'])
        && ($now - (int) $_SESSION['auth_time']) > (int) SW::$cfg['session_max_hours'] * 3600;
    if (($idle || $expired) && isset($_SESSION['user_id'])) {
        unset($_SESSION['user_id'], $_SESSION['auth_time']);
        session_regenerate_id(true);
        flash('info', 'flash.session_expired');
    }
    $_SESSION['last_activity'] = $now;
}

function flash(string $type, string $key, array $repl = []): void
{
    $_SESSION['flash'][] = ['type' => $type, 'key' => $key, 'repl' => $repl];
}

function take_flashes(): array
{
    $flashes = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return is_array($flashes) ? $flashes : [];
}

function csrf_field(): string
{
    $token = bin2hex(random_bytes(16));
    $list = isset($_SESSION['ot']) && is_array($_SESSION['ot']) ? $_SESSION['ot'] : [];
    $list[$token] = time();
    if (count($list) > 40) {
        $list = array_slice($list, -40, null, true);
    }
    $_SESSION['ot'] = $list;
    return '<input type="hidden" name="_csrf" value="' . e($token) . '">';
}

function csrf_ok(): bool
{
    $sent = $_POST['_csrf'] ?? '';
    if (!is_string($sent) || !isset($_SESSION['ot']) || !is_array($_SESSION['ot']) || !isset($_SESSION['ot'][$sent])) {
        return false;
    }
    unset($_SESSION['ot'][$sent]);
    return true;
}

function rate_allow(string $key, int $max, int $windowSeconds): bool
{
    $now = Clock::now()->getTimestamp();
    return SW::$db->tx(function () use ($key, $max, $windowSeconds, $now): bool {
        $row = SW::$db->one('SELECT window_start, cnt FROM rate_limits WHERE k = ?', [$key]);
        if ($row === null || ($now - (int) $row['window_start']) >= $windowSeconds) {
            SW::$db->run(
                'INSERT INTO rate_limits (k, window_start, cnt) VALUES (?, ?, 1)
                 ON CONFLICT(k) DO UPDATE SET window_start = excluded.window_start, cnt = 1',
                [$key, $now]
            );
            return true;
        }
        if ((int) $row['cnt'] >= $max) {
            return false;
        }
        SW::$db->run('UPDATE rate_limits SET cnt = cnt + 1 WHERE k = ?', [$key]);
        return true;
    });
}

function rate_gc(): void
{
    SW::$db->run('DELETE FROM rate_limits WHERE window_start < ?', [Clock::now()->getTimestamp() - 86400]);
}

function ip_key(): string
{
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    return substr(sw_hmac('ip|' . Clock::localDate() . '|' . $ip), 0, 24);
}
