<?php

// code: https://github.com/florianthepro/buergerabstimmung
// Stellt die Kommandozeile für Verwaltung und Testdaten bereit.

declare(strict_types=1);

function cli_main(array $argv): int
{
    $cmd = $argv[1] ?? 'help';
    if ($cmd === 'selftest') {
        Clock::setTimezone((string) SW::$cfg['timezone']);
        date_default_timezone_set('UTC');
        return cli_selftest();
    }
    sw_setup();
    if ($cmd === 'cron') {
        maintenance_tick();
        echo "ok\n";
        return 0;
    }
    if ($cmd === 'seed') {
        $n = isset($argv[2]) && preg_match('/^\d{1,5}$/', $argv[2]) === 1 ? (int) $argv[2] : 400;
        cli_seed($n);
        return 0;
    }
    if ($cmd === 'jurysim') {
        cli_jurysim();
        return 0;
    }
    if ($cmd === 'issue-card') {
        $n = isset($argv[2]) && preg_match('/^\d{1,4}$/', $argv[2]) === 1 ? (int) $argv[2] : 1;
        cli_issue_card($n);
        return 0;
    }
    if ($cmd === 'sync-keys') {
        return cli_sync_keys($argv[2] ?? '');
    }
    if ($cmd === 'setup-token') {
        if (!test_mode()) {
            echo "Testbetrieb ist bereits beendet; ein Einrichtungsschluessel wird nicht mehr gebraucht.\n";
            return 0;
        }
        echo setup_token() . "\n";
        return 0;
    }
    if ($cmd === 'config') {
        $stored = setup_load();
        echo $stored === [] ? "Keine Einstellungen in data/config.yaml.\n" : '';
        foreach (SW_SETUP_KEYS as $key) {
            printf("%-20s %s\n", $key, (string) ($stored[$key] ?? '-'));
        }
        return 0;
    }
    echo "Aufrufe: php index.php selftest | cron | seed [n] | jurysim | issue-card [n] | sync-keys [url] | setup-token | config\n";
    return $cmd === 'help' ? 0 : 1;
}

function cli_issue_card(int $count): void
{
    if (!card_supports_sodium()) {
        fwrite(STDERR, "Abbruch: PHP-sodium erforderlich.\n");
        return;
    }
    $dir = SW::$dataDir . '/issued';
    if (!is_dir($dir) && !mkdir($dir, 0750, true) && !is_dir($dir)) {
        fwrite(STDERR, "Abbruch: issued/ nicht anlegbar.\n");
        return;
    }
    for ($i = 0; $i < $count; $i++) {
        $pair = sodium_crypto_sign_keypair();
        $secret = sodium_crypto_sign_secretkey($pair);
        $pkHex = bin2hex(sodium_crypto_sign_publickey($pair));
        $handle = bin2hex(random_bytes(16));
        authorized_add([$pkHex], 'issue-card');
        $file = $dir . '/' . $handle . '.key';
        file_put_contents($file, base64_encode($secret), LOCK_EX);
        @chmod($file, 0600);
        echo "Autorisierter Ausweis ausgegeben.\n";
        echo "  Schluessel: " . substr($pkHex, 0, 16) . "…\n";
        echo "  Ausgabe-Link (im Browser oeffnen): /claim/" . $handle . "\n";
    }
    echo "Hinweis: Nur diese Schluessel koennen sich anmelden. Link der URL der Seite voranstellen.\n";
}

function cli_sync_keys(string $urlArg): int
{
    $url = $urlArg !== '' ? $urlArg : (string) SW::$cfg['authorized_keys_url'];
    if ($url === '') {
        echo "Keine Quelle konfiguriert (authorized_keys_url leer).\n";
        echo "In Deutschland gibt es keine staatliche Liste aller Ausweis-Schluessel;\n";
        echo "echte Pruefung laeuft ueber die BSI-Zertifikatskette im eID-Server.\n";
        echo "Diese Funktion ist der Anschlusspunkt fuer eine eigene Trust-Liste.\n";
        return 0;
    }
    if (preg_match('#^https://#', $url) !== 1) {
        fwrite(STDERR, "Abbruch: nur https-Quellen erlaubt.\n");
        return 1;
    }
    $ctx = stream_context_create(['http' => ['timeout' => 15], 'ssl' => ['verify_peer' => true, 'verify_peer_name' => true]]);
    $body = @file_get_contents($url, false, $ctx);
    if ($body === false) {
        fwrite(STDERR, "Abbruch: Quelle nicht erreichbar.\n");
        return 1;
    }
    preg_match_all('/[0-9a-fA-F]{64,128}/', $body, $mm);
    $added = authorized_add($mm[0], $url);
    printf("Allowlist aktualisiert: %d neue Schluessel aus %s\n", $added, $url);
    return 0;
}

function cli_seed(int $count): void
{
    $created = 0;
    $votes = 0;
    SW::$db->tx(function () use ($count, &$created, &$votes): void {
        $now = Clock::nowStr();
        for ($i = 0; $i < $count; $i++) {
            SW::$db->run(
                'INSERT INTO users (pseudonym_hash, lang, is_seed, created_at) VALUES (?, ?, 1, ?)',
                ['seed-' . bin2hex(random_bytes(28)), 'de', $now]
            );
            $created++;
        }
        $seedIds = array_map(static function (array $r): int {
            return (int) $r['id'];
        }, SW::$db->all('SELECT id FROM users WHERE is_seed = 1'));
        foreach (SW::$db->all("SELECT id FROM topics WHERE status = 'active'") as $topic) {
            $turnout = random_int(15, 60);
            $forShare = random_int(25, 75);
            foreach ($seedIds as $userId) {
                if (random_int(1, 100) > $turnout) {
                    continue;
                }
                $choice = random_int(1, 100) <= $forShare ? 'for' : 'against';

                SW::$db->run(
                    'INSERT OR IGNORE INTO votes (topic_id, voter_tag, choice, created_at, updated_at) VALUES (?, ?, ?, ?, ?)',
                    [(int) $topic['id'], vote_tag((int) $topic['id'], user_pk($userId)), $choice, $now, $now]
                );
                $votes++;
            }
        }
    });
    printf("Demo-Nutzer angelegt: %d, Stimmen erzeugt: %d\n", $created, $votes);
}

function cli_jurysim(): void
{
    maintenance_tick();
    $seats = SW::$db->all(
        "SELECT rj.report_id, rj.user_id
         FROM report_jurors rj
         JOIN reports r ON r.id = rj.report_id
         JOIN users u   ON u.id = rj.user_id
         WHERE r.status = 'voting' AND rj.vote IS NULL AND u.is_seed = 1"
    );
    $cast = 0;
    foreach ($seats as $seat) {
        if (random_int(1, 100) > 80) {
            continue;
        }
        $roll = random_int(1, 100);
        $vote = $roll <= 55 ? 'confirm' : ($roll <= 85 ? 'reject' : 'neutral');
        try {
            jury_cast((int) $seat['report_id'], (int) $seat['user_id'], $vote);
            $cast++;
        } catch (DomainException $e) {

        }
    }
    printf("Simulierte Jury-Stimmen: %d\n", $cast);
}

function cli_switch_db(string $tmpDir, string $name): void
{
    putenv('BUERGERABSTIMMUNG_DB=' . $tmpDir . '/' . $name . '.sqlite');
    SW::$db = new Db($tmpDir . '/' . $name . '.sqlite');
    SW::$db->migrate();
    sw_seed_categories();
}

function cli_add_users(int $count, string $prefix): array
{
    $ids = [];
    for ($i = 1; $i <= $count; $i++) {
        SW::$db->run(
            'INSERT INTO users (pseudonym_hash, lang, created_at) VALUES (?, ?, ?)',
            [$prefix . '-' . $i, 'de', Clock::nowStr()]
        );
        $ids[] = SW::$db->lastId();
    }
    return $ids;
}

function cli_make_topic(int $authorId, string $title): int
{
    $categoryId = (int) SW::$db->val('SELECT id FROM categories ORDER BY id LIMIT 1');
    $endDate = substr(Clock::addDaysStr(Clock::nowStr(), 30), 0, 10);
    return topic_create($authorId, $title, 'Ein Ziel für den Selbsttest dieses Themas.', 'Eine Begründung für den Selbsttest dieses Themas.', $categoryId, 'bund', null, 'date', $endDate, null);
}
