<?php

// code: https://github.com/florianthepro/buergerabstimmung
// Beantwortet die JSON-Abfragen der Live-Aktualisierung.

declare(strict_types=1);

function h_api_topics(): void
{
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    if (auth_user() === null) {
        http_response_code(401);
        echo '{}';
        exit;
    }
    $ids = [];
    foreach (explode(',', query_str('ids', 400)) as $raw) {
        if (preg_match('/^\d{1,10}$/', trim($raw)) === 1) {
            $ids[] = (int) $raw;
        }
    }
    $ids = array_slice(array_unique($ids), 0, 50);
    if ($ids === []) {
        echo '{}';
        exit;
    }
    $marks = implode(',', array_fill(0, count($ids), '?'));
    $rows = SW::$db->all(
        "SELECT t.id, t.status,
                (SELECT COUNT(*) FROM votes v WHERE v.topic_id = t.id AND v.choice = 'for') AS votes_for,
                (SELECT COUNT(*) FROM votes v WHERE v.topic_id = t.id AND v.choice = 'against') AS votes_against
         FROM topics t WHERE t.id IN ($marks)",
        $ids
    );
    $out = [];
    foreach ($rows as $row) {
        $out[(string) $row['id']] = [
            'f' => (int) $row['votes_for'],
            'a' => (int) $row['votes_against'],
            's' => (string) $row['status'],
        ];
    }
    echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function h_api_similar(): void
{
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    if (auth_user() === null) {
        http_response_code(401);
        echo '[]';
        exit;
    }
    $title = query_str('q', SW_TITLE_MAX);
    $exclude = query_str('not', 10);
    $out = [];
    foreach (topics_similar($title, $exclude === '' ? null : (int) $exclude, 4) as $row) {
        $out[] = ['id' => (int) $row['id'], 'title' => (string) $row['title']];
    }
    echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
