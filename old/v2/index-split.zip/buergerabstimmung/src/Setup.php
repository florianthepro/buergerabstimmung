<?php

// code: https://github.com/florianthepro/buergerabstimmung
// Richtet die Anwendung beim ersten Start ein und beendet den Testmodus.

declare(strict_types=1);

const SW_HTACCESS_DENY = <<<'TXT'
<IfModule mod_authz_core.c>
    Require all denied
</IfModule>
<IfModule !mod_authz_core.c>
    Order allow,deny
    Deny from all
</IfModule>
TXT;

const SW_HTACCESS_ROOT = <<<'TXT'

Options -Indexes -MultiViews
DirectoryIndex index.php
<IfModule mod_rewrite.c>
    RewriteEngine On
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteRule ^ index.php [L]
</IfModule>
<FilesMatch "\.(md|sqlite|sqlite-wal|sqlite-shm|log|key|lock)$">
    <IfModule mod_authz_core.c>
        Require all denied
    </IfModule>
    <IfModule !mod_authz_core.c>
        Order allow,deny
        Deny from all
    </IfModule>
</FilesMatch>
<FilesMatch "^\.">
    <IfModule mod_authz_core.c>
        Require all denied
    </IfModule>
    <IfModule !mod_authz_core.c>
        Order allow,deny
        Deny from all
    </IfModule>
</FilesMatch>
TXT;

function sw_setup(): void
{
    Clock::setTimezone((string) SW::$cfg['timezone']);
    date_default_timezone_set('UTC');
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');

    SW::$dataDir = SW_ROOT . '/data';
    if (!is_dir(SW::$dataDir) && !mkdir(SW::$dataDir, 0750, true) && !is_dir(SW::$dataDir)) {
        throw new RuntimeException('Verzeichnis data/ nicht anlegbar.');
    }
    ini_set('error_log', SW::$dataDir . '/php-error.log');

    $dataHt = SW::$dataDir . '/.htaccess';
    if (!is_file($dataHt)) {
        @file_put_contents($dataHt, SW_HTACCESS_DENY . "\n", LOCK_EX);
    }

    $rootHt = SW_ROOT . '/.htaccess';
    if (!is_file($rootHt)) {
        @file_put_contents($rootHt, SW_HTACCESS_ROOT . "\n", LOCK_EX);
    }
    $srcHt = SW_ROOT . '/src/.htaccess';
    if (!is_file($srcHt)) {
        @file_put_contents($srcHt, SW_HTACCESS_DENY . "\n", LOCK_EX);
    }

    $robots = SW_ROOT . '/robots.txt';
    if (!is_file($robots)) {
        @file_put_contents($robots, "User-agent: *\nDisallow: /\n", LOCK_EX);
    }

    $keyFile = SW::$dataDir . '/secret.key';
    if (!is_file($keyFile)) {
        if (file_put_contents($keyFile, bin2hex(random_bytes(32)), LOCK_EX) === false) {
            throw new RuntimeException('Geheimnis-Datei nicht schreibbar.');
        }
        @chmod($keyFile, 0600);
    }
    $pepper = trim((string) file_get_contents($keyFile));
    if (strlen($pepper) < 32) {
        throw new RuntimeException('Geheimnis-Datei beschädigt.');
    }
    SW::$pepper = $pepper;

    if (card_supports_sodium()) {
        $srvFile = SW::$dataDir . '/server_sign.key';
        if (!is_file($srvFile)) {
            $pair = sodium_crypto_sign_keypair();
            if (file_put_contents($srvFile, base64_encode(sodium_crypto_sign_secretkey($pair)), LOCK_EX) === false) {
                throw new RuntimeException('Server-Signaturschlüssel nicht schreibbar.');
            }
            @chmod($srvFile, 0600);
        }
        SW::$serverSign = base64_decode(trim((string) file_get_contents($srvFile)), true) ?: '';
    }

    setup_apply(setup_load());

    $dbPath = getenv('BUERGERABSTIMMUNG_DB') ?: SW::$dataDir . '/buergerabstimmung.sqlite';
    SW::$db = new Db($dbPath);
    SW::$db->migrate();
    sw_seed_categories();

    if ((string) SW::$cfg['testmode_end'] === 'live' && test_mode()) {
        test_mode_end();
    }
}

const SW_SETUP_KEYS = [
    'eid_mode', 'eid_server_url', 'eid_server_cert', 'eid_server_key',
    'eid_client_url', 'authorized_keys_url', 'nect_start',
];

function setup_file(): string
{
    return SW::$dataDir . '/config.yaml';
}

function setup_token_file(): string
{
    return SW::$dataDir . '/setup.token';
}

function setup_token(): string
{
    $file = setup_token_file();
    if (!is_file($file)) {
        @file_put_contents($file, bin2hex(random_bytes(16)) . "\n", LOCK_EX);
        @chmod($file, 0600);
    }
    return trim((string) @file_get_contents($file));
}

function setup_load(): array
{
    $file = setup_file();
    if (!is_file($file)) {
        return [];
    }
    $out = [];
    foreach (explode("\n", (string) file_get_contents($file)) as $line) {
        if (preg_match('/^([a-z_]+):\s*"(.*)"\s*$/', trim($line), $m) !== 1) {
            continue;
        }
        if (in_array($m[1], SW_SETUP_KEYS, true)) {
            $out[$m[1]] = str_replace(['\\"', '\\\\'], ['"', '\\'], $m[2]);
        }
    }
    return $out;
}

function setup_save(array $values): bool
{
    $lines = [];
    foreach (SW_SETUP_KEYS as $key) {
        if (!isset($values[$key])) {
            continue;
        }
        $value = str_replace(['\\', '"'], ['\\\\', '\\"'], (string) $values[$key]);
        $lines[] = $key . ': "' . $value . '"';
    }
    $ok = @file_put_contents(setup_file(), implode("\n", $lines) . "\n", LOCK_EX) !== false;
    if ($ok) {
        @chmod(setup_file(), 0600);
    }
    return $ok;
}

function setup_apply(array $values): void
{
    foreach ($values as $key => $value) {
        if ($key === 'nect_start') {
            $providers = SW::$cfg['eid_providers'];
            $providers['nect']['start'] = (string) $value;
            SW::$cfg['eid_providers'] = $providers;
            continue;
        }
        if (in_array($key, SW_SETUP_KEYS, true)) {
            SW::$cfg[$key] = $value;
        }
    }
}

function setup_read_post(): array
{
    return [
        'eid_mode'            => post_str('eid_mode', 10) === 'eid' ? 'eid' : 'demo',
        'eid_server_url'      => post_str('eid_server_url', 300),
        'eid_server_cert'     => post_str('eid_server_cert', 300),
        'eid_server_key'      => post_str('eid_server_key', 300),
        'eid_client_url'      => post_str('eid_client_url', 200),
        'authorized_keys_url' => post_str('authorized_keys_url', 300),
        'nect_start'          => post_str('nect_start', 300),
    ];
}

function setup_validate(array $in): array
{
    $errors = [];
    if ($in['eid_client_url'] === '') {
        $in['eid_client_url'] = (string) SW_CONFIG['eid_client_url'];
    }
    if (preg_match('#^https?://[^\s"\']+$#', $in['eid_client_url']) !== 1) {
        $errors[] = 'setup.err_client';
    }
    foreach (['eid_server_url', 'authorized_keys_url', 'nect_start'] as $key) {
        if ($in[$key] !== '' && preg_match('#^https://[^\s"\']+$#', $in[$key]) !== 1) {
            $errors[] = 'setup.err_https';
        }
    }
    foreach (['eid_server_cert', 'eid_server_key'] as $key) {
        if ($in[$key] !== '' && !is_readable($in[$key])) {
            $errors[] = 'setup.err_file';
        }
    }
    if ($in['eid_mode'] === 'eid' && $in['eid_server_url'] === '') {
        $errors[] = 'setup.err_server_missing';
    }
    if ($in['eid_mode'] === 'demo' && $in['authorized_keys_url'] === '' && authorized_count_stable() === 0) {
        $errors[] = 'setup.err_list_empty';
    }
    return [array_values(array_unique($errors)), $in];
}

function setup_probe(array $cfg): bool
{
    return eid_server_useid($cfg) !== null;
}

function setup_probe_list(string $url): ?int
{
    if ($url === '') {
        return authorized_count_stable();
    }
    if (preg_match('#^https://#', $url) !== 1) {
        return null;
    }
    $ctx = stream_context_create([
        'http' => ['timeout' => 8],
        'ssl'  => ['verify_peer' => true, 'verify_peer_name' => true],
    ]);
    $body = @file_get_contents($url, false, $ctx);
    if ($body === false) {
        return null;
    }
    $found = preg_match_all('/[0-9a-fA-F]{64,128}/', $body, $mm);
    return $found === false ? null : $found;
}

function setup_check_stamp(array $values): string
{
    return sw_hmac('setup-check|' . implode('|', [
        (string) ($values['eid_mode'] ?? ''),
        (string) ($values['eid_server_url'] ?? ''),
        (string) ($values['eid_server_cert'] ?? ''),
        (string) ($values['eid_server_key'] ?? ''),
        (string) ($values['authorized_keys_url'] ?? ''),
    ]));
}

function setup_checked(array $values): bool
{
    return hash_equals((string) ($_SESSION['setup_check'] ?? ''), setup_check_stamp($values));
}

function setup_ready(): array
{
    $htaccess = is_file(SW_ROOT . '/.htaccess');
    return [
        ['setup.check_data', is_writable(SW::$dataDir)],
        ['setup.check_https', sw_is_https()],
        ['setup.check_sodium', card_supports_sodium()],
        ['setup.check_htaccess', $htaccess],
    ];
}

function test_mode(): bool
{
    if (SW::$testMode === null) {
        SW::$testMode = SW::$db !== null
            && (string) (SW::$db->val("SELECT v FROM schema_info WHERE k = 'test_mode'") ?? '1') === '1';
    }
    return SW::$testMode;
}

function test_mode_end(): void
{
    SW::$db->tx(function (): void {
        SW::$db->run('DELETE FROM report_jurors');
        SW::$db->run('DELETE FROM reports');
        SW::$db->run('DELETE FROM votes');
        SW::$db->run('DELETE FROM favorites');
        SW::$db->run('DELETE FROM topics');
        SW::$db->run('DELETE FROM users WHERE is_system = 0');
        SW::$db->run('DELETE FROM rate_limits');
        SW::$db->run('DELETE FROM eid_flows');
        SW::$db->run(
            "INSERT INTO schema_info (k, v) VALUES ('test_mode', '0')
             ON CONFLICT(k) DO UPDATE SET v = '0'"
        );
    });
    SW::$testMode = false;

    authorized_remove(test_keys_load());
    @unlink(test_keys_file());
    log_line('SECURITY', 'test_mode_ended', []);
}
