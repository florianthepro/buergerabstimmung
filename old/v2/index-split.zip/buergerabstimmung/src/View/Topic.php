<?php

// code: https://github.com/florianthepro/buergerabstimmung
// Stellt Themenliste, Themenseite, Formulare und Stimmbalken dar.

declare(strict_types=1);

function scope_text(array $row): string
{
    $name = (string) ($row['scope_name'] ?? '');
    return $name !== '' ? $name : t('scope.bund');
}

function p_topic_card(array $row): string
{
    $html = '<article class="card topic-card" data-topic="' . (int) $row['id'] . '"><div class="topic-card-meta">'
        . '<span class="badge">' . e(cat_name($row)) . '</span>'
        . '<span class="badge">' . e(scope_text($row)) . '</span></div>'
        . '<h3 class="topic-card-title"><a href="' . e(url('/topic/' . (int) $row['id'])) . '">' . e((string) $row['title']) . '</a></h3>'
        . '<p class="topic-card-goal">' . e((string) $row['goal']) . '</p>'
        . p_votebar((int) $row['votes_for'], (int) $row['votes_against'], true);
    if (!empty($row['my_choice'])) {
        $html .= '<p class="topic-card-mine">'
            . e(t('topic.your_vote', ['choice' => t($row['my_choice'] === 'for' ? 'vote.for' : 'vote.against')])) . '</p>';
    }
    return $html . '</article>';
}

function p_vote_button(string $choice, ?string $myVote): string
{
    $mine = $myVote === $choice;
    return '<button type="submit" name="choice" value="' . e($choice) . '"'
        . ' class="btn vote-btn' . ($mine ? ' is-active' : '') . '"'
        . ' aria-pressed="' . ($mine ? 'true' : 'false') . '">'
        . e(t($choice === 'for' ? 'vote.for' : 'vote.against')) . '</button>';
}

function p_vote_locked(?string $myVote): string
{
    $html = '<div class="vote-actions">';
    foreach (['for', 'against'] as $choice) {
        $mine = $myVote === $choice;
        $state = $myVote === null ? ' is-dim' : ($mine ? ' is-locked' : ' is-dim');
        $html .= '<button type="button" class="btn vote-btn' . $state . '" disabled'
            . ' aria-pressed="' . ($mine ? 'true' : 'false') . '">'
            . e(t($choice === 'for' ? 'vote.for' : 'vote.against')) . '</button>';
    }
    return $html . '</div>';
}

function p_votebar(int $for, int $against, bool $slim = false): string
{
    $total = $for + $against;
    $pctFor = $total > 0 ? (int) round($for * 100 / $total) : 0;
    $pctAgainst = $total > 0 ? 100 - $pctFor : 0;
    $cls = $slim ? 'votefig votefig-slim' : 'votefig';
    return '<div class="' . $cls . '" data-fig>'
        . '<div class="votebar" role="img" aria-label="' . e(t('vote.bar_aria')) . '">'
        . '<span class="votebar-for w-' . $pctFor . '" data-bar="for"></span>'
        . '<span class="votebar-against w-' . $pctAgainst . '" data-bar="against"></span>'
        . '</div><div class="votebar-legend">'
        . '<span><span class="dot dot-for" aria-hidden="true"></span>' . e(t('vote.for'))
        . ' <b data-num="for">' . e(num($for)) . '</b>'
        . '<span class="pct" data-pct="for">/ ' . $pctFor . ' %</span></span>'
        . '<span><span class="dot dot-against" aria-hidden="true"></span>' . e(t('vote.against'))
        . ' <b data-num="against">' . e(num($against)) . '</b>'
        . '<span class="pct" data-pct="against">/ ' . $pctAgainst . ' %</span></span>'
        . '</div></div>';
}

function topic_end_fields(array $old): string
{
    $byDate = (bool) ($old['end_by_date'] ?? true);
    $byTarget = (bool) ($old['end_by_target'] ?? false);
    if (!$byDate && !$byTarget) {
        $byDate = true;
    }
    $defaultDate = substr(Clock::addDaysStr(Clock::nowStr(), 30), 0, 10);
    $date = ($old['end_date'] ?? '') !== '' ? (string) $old['end_date'] : $defaultDate;
    $value = ($old['end_value'] ?? '') !== '' ? (string) $old['end_value'] : '';
    $unit = ($old['end_unit'] ?? '') === 'percent' ? 'percent' : 'count';
    $minDate = substr(Clock::addDaysStr(Clock::nowStr(), 1), 0, 10);
    $maxDate = substr(Clock::addDaysStr(Clock::nowStr(), 365), 0, 10);
    return '<fieldset class="end-fields" data-end-fields><legend>' . e(t('topic.f_end')) . '</legend>'
        . '<label class="check"><input type="checkbox" name="end_by_date" value="1" data-end-toggle="date"'
        . ($byDate ? ' checked' : '') . '><span>' . e(t('topic.end_by_date')) . '</span></label>'
        . '<div class="end-row" data-end-part="date"' . ($byDate ? '' : ' hidden') . '>'
        . '<input type="date" name="end_date" value="' . e($date) . '" min="' . e($minDate) . '" max="' . e($maxDate) . '" aria-label="' . e(t('topic.end_by_date')) . '">'
        . '</div>'
        . '<label class="check"><input type="checkbox" name="end_by_target" value="1" data-end-toggle="target"'
        . ($byTarget ? ' checked' : '') . '><span>' . e(t('topic.end_by_target')) . '</span></label>'
        . '<div class="end-row" data-end-part="target"' . ($byTarget ? '' : ' hidden') . '>'
        . '<input type="number" name="end_value" min="1" max="100000000" value="' . e($value) . '" inputmode="numeric" placeholder="' . e(t('topic.end_value_ph')) . '" aria-label="' . e(t('topic.end_by_target')) . '">'
        . '<select name="end_unit" aria-label="' . e(t('topic.end_unit')) . '">'
        . '<option value="count"' . ($unit === 'count' ? ' selected' : '') . '>' . e(t('topic.end_unit_count')) . '</option>'
        . '<option value="percent"' . ($unit === 'percent' ? ' selected' : '') . '>' . e(t('topic.end_unit_percent')) . '</option>'
        . '</select></div>'
        . '</fieldset>';
}

function topic_form_html(array $errors, array $old, string $action, string $submitKey, ?int $selfId = null): string
{
    $formId = $selfId === null ? 'new' : ('e' . $selfId);
    $html = '';
    if ($errors !== []) {
        $html .= '<div class="flash flash-error" role="alert"><ul class="plain-list">';
        foreach ($errors as $error) {
            $html .= '<li>' . e(t($error)) . '</li>';
        }
        $html .= '</ul></div>';
    }
    $html .= '<form class="form-stack" method="post" action="' . e(url($action)) . '">' . csrf_field()
        . '<label><span>' . e(t('topic.f_title')) . '</span>'
        . '<input type="text" id="title-' . e($formId) . '" name="title" required minlength="' . SW_TITLE_MIN . '" maxlength="' . SW_TITLE_MAX . '" value="' . e((string) $old['title']) . '"></label>'
        . '<div class="similar-hint" hidden data-similar-for="#title-' . e($formId) . '"'
        . ($selfId !== null ? ' data-similar-not="' . (int) $selfId . '"' : '')
        . ' data-similar-label="' . e(t('topic.similar_hint')) . '"></div>'
        . '<label><span>' . e(t('topic.f_goal')) . '</span>'
        . '<textarea name="goal" rows="3" required minlength="' . SW_GOAL_MIN . '" maxlength="' . SW_GOAL_MAX . '">' . e((string) $old['goal']) . '</textarea></label>'
        . '<label><span>' . e(t('topic.f_reasoning')) . '</span>'
        . '<textarea name="reasoning" rows="5" required minlength="' . SW_REASONING_MIN . '" maxlength="' . SW_REASONING_MAX . '">' . e((string) $old['reasoning']) . '</textarea></label>'
        . '<div class="form-row"><label><span>' . e(t('topic.f_category')) . '</span><select name="category_id" required>'
        . '<option value="">' . e(t('topic.f_choose')) . '</option>';
    foreach (categories() as $category) {
        $sel = (int) $old['category_id'] === (int) $category['id'] ? ' selected' : '';
        $html .= '<option value="' . (int) $category['id'] . '"' . $sel . '>' . e(cat_name($category)) . '</option>';
    }
    $html .= '</select></label>'
        . '<label><span>' . e(t('topic.f_scope')) . '</span>'
        . scope_picker('scope', ($old['scope'] ?? 'de') !== '' ? (string) $old['scope'] : 'de', false)
        . '</label></div>'
        . topic_end_fields($old)
        . '<div><button type="submit" class="btn btn-primary">' . e(t($submitKey)) . '</button></div></form>';
    return $html;
}

function v_main(array $formErrors = [], ?array $formOld = null): void
{
    $user = require_user();
    $userId = (int) $user['id'];
    $html = '';

    $upcoming = jury_upcoming_for($userId);
    if ($upcoming !== null) {
        $html .= '<div class="flash">' . e(t('me.jury_upcoming', ['date' => Clock::displayLocal((string) $upcoming['voting_starts_at'], t('common.date_format'))])) . '</div>';
    }

    $scopeValue = query_str('gebiet', 160);
    $scopeDecoded = $scopeValue === '' ? null : scope_decode($scopeValue);
    if ($scopeDecoded === null) {
        $scopeValue = '';
    }
    $filters = [
        'category' => query_str('category', 64),
        'level'    => $scopeDecoded === null ? '' : $scopeDecoded[0],
        'scope'    => $scopeDecoded === null || $scopeDecoded[1] === null ? '' : $scopeDecoded[1],
        'gebiet'   => $scopeValue,
        'q'        => query_str('q', 80),
        'sort'     => in_array(query_str('sort', 10), ['new', 'top'], true) ? query_str('sort', 10) : 'net',
    ];
    $page = query_int('page', 1, 500, 1);
    $perPage = (int) SW::$cfg['page_size'];
    $result = topics_list($filters, $page, $perPage, $userId);
    $pages = max(1, (int) ceil($result['total'] / $perPage));

    $html .= '<div class="action-bar">'
        . '<a class="btn btn-primary" href="#modal-new">' . e(t('topic.new_title')) . '</a>'
        . '<a class="btn btn-outline" href="#modal-search">' . e(t('topics.search')) . '</a>';
    if ($filters['q'] !== '' || $filters['category'] !== '' || $filters['gebiet'] !== '') {
        $html .= '<a class="btn btn-ghost" href="' . e(url('/')) . '">' . e(t('topics.clear')) . '</a>';
    }
    $html .= '</div>';

    $chips = '';
    foreach (fav_list($userId) as $favorite) {
        if ($favorite['kind'] === 'topic') {
            if (($favorite['topic_title'] ?? null) === null) {
                continue;
            }
            $label = (string) $favorite['topic_title'];
            if (mb_strlen($label) > 34) {
                $label = mb_substr($label, 0, 33) . '…';
            }
            $href = url('/topic/' . (int) $favorite['ref']);
        } elseif ($favorite['kind'] === 'category') {
            $label = SW::$lang === 'de' ? (string) ($favorite['name_de'] ?? $favorite['ref']) : (string) ($favorite['name_en'] ?? $favorite['ref']);
            $href = url('/') . '?category=' . rawurlencode((string) $favorite['ref']);
        } else {
            $gebiet = fav_to_gebiet((string) $favorite['ref']);
            if ($gebiet === null) {
                continue;
            }
            $parts = explode(':', (string) $favorite['ref'], 2);
            $label = $parts[0] === 'bund' || !isset($parts[1]) ? t('scope.bund') : $parts[1];
            $href = url('/') . '?gebiet=' . rawurlencode($gebiet);
        }
        $chips .= '<a class="btn btn-ghost btn-sm fav-chip" href="' . e($href) . '">' . icon_bookmark(true) . e($label) . '</a>';
    }
    if ($chips !== '') {
        $html .= '<div class="fav-chips">' . $chips . '</div>';
    }

    $recent = [];
    foreach (topics_voted_by($userId) as $row) {
        if (!in_array((string) $row['status'], ['removed', 'archived'], true) && empty($row['locked'])) {
            $recent[] = $row;
        }
    }
    if ($recent !== []) {
        $html .= '<section class="recent-votes"><h2>' . e(t('home.recent_votes')) . '</h2><ul class="row-list">';
        foreach ($recent as $row) {
            $until = Clock::addHoursStr((string) $row['voted_at'], SW_VOTE_CHANGE_HOURS);
            $html .= '<li class="row-item"><div class="row-main">'
                . '<a href="' . e(url('/topic/' . (int) $row['id'])) . '">' . e((string) $row['title']) . '</a></div>'
                . '<div class="row-side"><span class="dot ' . ($row['my_choice'] === 'for' ? 'dot-for' : 'dot-against') . '" aria-hidden="true"></span>'
                . e(t($row['my_choice'] === 'for' ? 'vote.for' : 'vote.against'))
                . ' <span class="muted">· ' . e(t('vote.changeable_until', ['date' => Clock::displayLocal($until, t('common.datetime_format'))])) . '</span></div></li>';
        }
        $html .= '</ul></section>';
    }

    if ($result['rows'] === []) {
        $html .= '<p class="muted">' . e(t('topics.none')) . '</p>';
    } else {
        $html .= '<div class="topic-grid">';
        foreach ($result['rows'] as $row) {
            $html .= p_topic_card($row);
        }
        $html .= '</div>';
    }
    if ($pages > 1) {
        $mkQuery = static function (int $p) use ($filters): string {
            $keep = ['category' => $filters['category'], 'gebiet' => $filters['gebiet'],
                     'q' => $filters['q'], 'sort' => $filters['sort'], 'page' => $p];
            $params = array_filter($keep, static function ($v) {
                return $v !== '' && $v !== null;
            });
            return $params === [] ? '' : '?' . http_build_query($params);
        };
        $html .= '<nav class="pagination" aria-label="Pagination">';
        if ($page > 1) {
            $html .= '<a class="btn btn-ghost btn-sm" href="' . e(url('/') . $mkQuery($page - 1)) . '">&laquo; ' . e(t('topics.prev')) . '</a>';
        }
        $html .= '<span class="muted">' . e(t('topics.page_of', ['p' => $page, 'n' => $pages])) . '</span>';
        if ($page < $pages) {
            $html .= '<a class="btn btn-ghost btn-sm" href="' . e(url('/') . $mkQuery($page + 1)) . '">' . e(t('topics.next')) . ' &raquo;</a>';
        }
        $html .= '</nav>';
    }

    $old = $formOld ?? ['title' => '', 'goal' => '', 'reasoning' => '', 'category_id' => 0, 'scope' => 'de',
                        'end_by_date' => true, 'end_date' => '', 'end_by_target' => false,
                        'end_value' => '', 'end_unit' => 'count'];
    if (topic_has_posted_today($userId)) {
        $newInner = '<p class="muted">' . e(t('topic.posted_today'))
            . '<span class="countdown" data-countdown-to="' . e(Clock::nextLocalMidnightUtcStr()) . '" data-label="' . e(t('topic.next_in')) . '"></span></p>';
    } else {
        $newInner = topic_form_html($formErrors, $old, '/topics', 'topic.submit');
    }
    $html .= modal('modal-new', t('topic.new_title'), $newInner);

    $searchInner = '<form class="form-stack" method="get" action="' . e(url('/')) . '">'
        . '<label><span>' . e(t('topics.search')) . '</span><input type="search" name="q" maxlength="80" value="' . e($filters['q']) . '"></label>'
        . '<label><span>' . e(t('topics.filter_category')) . '</span><select name="category">'
        . '<option value="">' . e(t('topics.filter_all')) . '</option>';
    foreach (categories() as $category) {
        $sel = $filters['category'] === $category['slug'] ? ' selected' : '';
        $searchInner .= '<option value="' . e((string) $category['slug']) . '"' . $sel . '>' . e(cat_name($category)) . '</option>';
    }
    $searchInner .= '</select></label>'
        . '<label><span>' . e(t('topic.f_scope')) . '</span>'
        . scope_picker('gebiet', $filters['gebiet'], true)
        . '</label>'
        . '<label><span>' . e(t('topics.sort')) . '</span><select name="sort">'
        . '<option value="net"' . ($filters['sort'] === 'net' ? ' selected' : '') . '>' . e(t('topics.sort_net')) . '</option>'
        . '<option value="new"' . ($filters['sort'] === 'new' ? ' selected' : '') . '>' . e(t('topics.sort_new')) . '</option>'
        . '<option value="top"' . ($filters['sort'] === 'top' ? ' selected' : '') . '>' . e(t('topics.sort_top')) . '</option>'
        . '</select></label>'
        . '<div><button type="submit" class="btn btn-primary">' . e(t('topics.apply')) . '</button></div></form>';
    $html .= modal('modal-search', t('topics.search'), $searchInner);

    render(t('app.tagline'), $html);
}

function topic_end_text(array $topic): string
{
    if ($topic['status'] === 'archived') {
        return t('topic.archived_badge');
    }
    if ($topic['status'] === 'closed') {
        return t('topic.ended');
    }
    $date = $topic['end_date'] !== null
        ? Clock::displayLocal((string) $topic['end_date'] . ' 00:00:00', t('common.date_format'))
        : null;
    $target = $topic['end_target'] !== null ? (int) $topic['end_target'] : null;
    $have = num((int) $topic['votes_for'] + (int) $topic['votes_against']);
    if ($date !== null && $target !== null) {
        return t('topic.ends_both', ['date' => $date, 'have' => $have, 'target' => num($target)]);
    }
    if ($date !== null) {
        return t('topic.ends_on', ['date' => $date]);
    }
    if ($target !== null) {
        return t('topic.ends_count', ['have' => $have, 'target' => num($target)]);
    }
    return '';
}

function fav_menu(int $userId, int $topicId, string $catRef, string $catLabel, string $scopeRef, string $scopeLabel): string
{
    $back = '/topic/' . $topicId;
    $items = [
        ['topic', (string) $topicId, t('topic.this'), fav_is($userId, 'topic', (string) $topicId)],
        ['category', $catRef, $catLabel, fav_is($userId, 'category', $catRef)],
        ['scope', $scopeRef, $scopeLabel, fav_is($userId, 'scope', $scopeRef)],
    ];
    $any = false;
    foreach ($items as $item) {
        $any = $any || $item[3];
    }
    $html = '<details class="fav-menu"><summary class="fav-toggle' . ($any ? ' is-on' : '')
        . '" title="' . e(t('topic.remember')) . '" aria-label="' . e(t('topic.remember')) . '" role="button">'
        . icon_bookmark($any) . '</summary><div class="fav-pop">';
    foreach ($items as [$kind, $ref, $label, $on]) {
        $html .= '<form method="post" action="' . e(url('/favorite')) . '">' . csrf_field()
            . '<input type="hidden" name="kind" value="' . e($kind) . '">'
            . '<input type="hidden" name="ref" value="' . e($ref) . '">'
            . '<input type="hidden" name="return" value="' . e($back) . '">'
            . '<button type="submit" class="fav-item' . ($on ? ' is-on' : '') . '">'
            . '<span>' . e($label) . '</span>' . ($on ? icon_bookmark(true) : '')
            . '</button></form>';
    }
    return $html . '</div></details>';
}

function v_topic(int $id): void
{
    $topic = topic_find($id);
    if ($topic === null) {
        v_error_404();
    }
    topic_close_if_due($topic);
    $topic = topic_find($id);
    if ($topic['status'] === 'removed') {
        $html = '<article class="card"><h1>' . e(t('topic.removed_title')) . '</h1>'
            . '<p class="muted">' . e(t('topic.removed_text')) . '</p>'
            . '<p><a class="btn btn-outline btn-sm" href="' . e(url('/')) . '">' . e(t('common.back_home')) . '</a></p></article>';
        render(t('topic.removed_title'), $html);
    }
    $user = auth_user();
    $userId = $user === null ? null : (int) $user['id'];
    $voteRow = $userId === null ? null : topic_user_vote_row($id, $userId);
    $myVote = $voteRow === null ? null : (string) $voteRow['choice'];
    $isAuthor = $userId !== null && (int) $topic['author_id'] === $userId;
    $openReport = report_open_for($id);
    $archived = $topic['status'] === 'archived';
    $closed = $topic['status'] !== 'active';
    $scopeRef = $topic['scope_level'] === 'bund' ? 'bund' : $topic['scope_level'] . ':' . (string) $topic['scope_name'];

    $html = '<article class="topic-detail"><div class="topic-card-meta">'
        . '<span class="badge">' . e(cat_name($topic)) . '</span>'
        . '<span class="badge">' . e(scope_text($topic)) . '</span>'
        . ($archived ? '<span class="badge badge-danger">' . e(t('topic.archived_badge')) . '</span>'
            : ($closed ? '<span class="badge badge-danger">' . e(t('topic.ended')) . '</span>' : ''))
        . '</div>'
        . '<h1>' . e((string) $topic['title']) . '</h1>'
        . '<p class="muted">' . e(Clock::displayLocal((string) $topic['created_at'], t('common.date_format')))
        . ' · ' . e(topic_end_text($topic)) . '</p>'
        . '<section class="card"><h2 class="field-label">' . e(t('topic.goal_label')) . '</h2>'
        . '<p>' . nl2br(e((string) $topic['goal'])) . '</p>'
        . '<h2 class="field-label">' . e(t('topic.reasoning_label')) . '</h2>'
        . '<p>' . nl2br(e((string) $topic['reasoning'])) . '</p></section>';

    $barFor = (int) $topic['votes_for'];
    $barAgainst = (int) $topic['votes_against'];
    $html .= '<section class="card" data-topic="' . (int) $topic['id'] . '">' . p_votebar($barFor, $barAgainst);
    if ($archived) {
        $html .= '<p class="muted">' . e(t('topic.archived_note')) . '</p>';
    } elseif ($user === null) {
        $html .= '<p><a class="btn btn-primary" href="' . e(url('/auth')) . '">' . e(t('vote.login_hint')) . '</a></p>';
    } elseif ($closed || ($voteRow !== null && $voteRow['locked'])) {
        $html .= p_vote_locked($myVote);
    } else {
        $html .= '<form class="vote-actions" method="post" action="' . e(url('/vote')) . '">' . csrf_field()
            . '<input type="hidden" name="topic_id" value="' . (int) $topic['id'] . '">'
            . p_vote_button('for', $myVote) . p_vote_button('against', $myVote);
        if ($myVote !== null) {
            $html .= '<button type="submit" name="choice" value="none" class="btn btn-ghost">' . e(t('vote.withdraw')) . '</button>';
        }
        $html .= '</form>';
    }
    $html .= '</section><section class="topic-tools">';
    if ($user !== null) {
        $html .= fav_menu(
            (int) $user['id'],
            (int) $topic['id'],
            (string) $topic['category_slug'],
            cat_name($topic),
            $scopeRef,
            scope_text($topic)
        );
    }
    $locked = topic_has_votes((int) $topic['id']);
    if ($isAuthor && !$archived) {
        $html .= '<a class="btn btn-ghost btn-sm" href="' . e(url('/topic/' . (int) $topic['id'] . '/edit')) . '">' . e(t('topic.edit')) . '</a>';
        if (!$locked) {
            $html .= '<a class="link-quiet" href="#modal-del">' . e(t('topic.archive')) . '</a>';
        }
    }
    if ($openReport !== null) {
        $html .= '<span class="muted">' . e(t('topic.report_open')) . '</span>';
    } elseif ($user !== null && !$isAuthor && !$closed) {
        $html .= '<a class="link-quiet" href="' . e(url('/report/' . (int) $topic['id'])) . '">' . e(t('topic.report_link')) . '</a>';
    }
    $html .= '</section>';
    $similar = topics_similar((string) $topic['title'], (int) $topic['id'], 4);
    if ($similar !== []) {
        $html .= '<section class="similar"><h2 class="card-h">' . e(t('topic.similar')) . '</h2><ul class="plain-list">';
        foreach ($similar as $row) {
            $html .= '<li><a href="' . e(url('/topic/' . (int) $row['id'])) . '">' . e((string) $row['title']) . '</a></li>';
        }
        $html .= '</ul></section>';
    }
    $html .= '</article>';

    if ($isAuthor && !$locked && !$archived) {
        $delInner = '<p class="muted">' . e(t('topic.archive_confirm')) . '</p>'
            . '<form method="post" action="' . e(url('/topic/' . (int) $topic['id'] . '/archive')) . '">' . csrf_field()
            . '<div class="btn-row"><button type="submit" class="btn btn-danger">' . e(t('topic.archive')) . '</button>'
            . '<a class="btn btn-ghost" href="#">' . e(t('common.close')) . '</a></div></form>';
        $html .= modal('modal-del', t('topic.archive'), $delInner);
    }
    render((string) $topic['title'], $html);
}

function v_topic_edit(int $id, array $errors = [], ?array $old = null): void
{
    $user = require_user();
    $topic = topic_find($id);
    if ($topic === null) {
        v_error_404();
    }
    if ((int) $topic['author_id'] !== (int) $user['id']
        || in_array((string) $topic['status'], ['removed', 'archived'], true)) {
        flash('error', 'flash.not_author');
        redirect('/topic/' . $id);
    }
    if ($old === null) {
        $scopeVal = $topic['scope_level'] === 'bund' ? 'de'
            : ($topic['scope_level'] === 'bundesland' ? 'bl:' . $topic['scope_name'] : 'kr:');

        if ($topic['scope_level'] === 'landkreis') {
            foreach (SW_REGIONS as $land => $kreise) {
                if (in_array((string) $topic['scope_name'], $kreise, true)) {
                    $scopeVal = 'kr:' . $land . ':' . $topic['scope_name'];
                    break;
                }
            }
        }
        $old = [
            'title' => (string) $topic['title'],
            'goal' => (string) $topic['goal'],
            'reasoning' => (string) $topic['reasoning'],
            'category_id' => (int) $topic['category_id'],
            'scope' => $scopeVal,
            'end_by_date' => $topic['end_date'] !== null,
            'end_date' => (string) ($topic['end_date'] ?? ''),
            'end_by_target' => $topic['end_target'] !== null,
            'end_value' => (string) ($topic['end_target'] ?? ''),
            'end_unit' => 'count',
        ];
    }
    $html = '<h1>' . e(t('topic.edit')) . '</h1>'
        . '<div class="card">' . topic_form_html($errors, $old, '/topic/' . $id . '/edit', 'topic.save', $id)
        . '<p><a class="link-quiet" href="' . e(url('/topic/' . $id)) . '">' . e(t('report.cancel')) . '</a></p></div>';
    render(t('topic.edit'), $html);
}
