<?php

// code: https://github.com/florianthepro/buergerabstimmung
// Nimmt Stimmen entgegen und schließt Themen bei erreichtem Ende.

declare(strict_types=1);

const SW_VOTE_CHANGE_HOURS = 24;

function vote_tag(int $topicId, string $pkHex): string
{
    return sw_hmac('vote|' . $topicId . '|' . $pkHex);
}

function user_pk(int $userId): string
{
    return (string) SW::$db->val('SELECT pseudonym_hash FROM users WHERE id = ?', [$userId]);
}

function topic_close_if_due(array $topic): string
{
    if ($topic['status'] !== 'active') {
        return (string) $topic['status'];
    }

    $close = false;
    if ($topic['end_date'] !== null && Clock::localDate() > (string) $topic['end_date']) {
        $close = true;
    }
    if ($topic['end_target'] !== null) {
        $total = (int) SW::$db->val('SELECT COUNT(*) FROM votes WHERE topic_id = ?', [(int) $topic['id']]);
        if ($total >= (int) $topic['end_target']) {
            $close = true;
        }
    }
    if ($close) {
        SW::$db->run("UPDATE topics SET status = 'closed' WHERE id = ? AND status = 'active'", [(int) $topic['id']]);
        return 'closed';
    }
    return 'active';
}

function vote_cast(int $userId, int $topicId, string $choice): void
{
    if (!in_array($choice, ['for', 'against', 'none'], true)) {
        throw new DomainException('flash.invalid_input');
    }
    $topic = SW::$db->one('SELECT * FROM topics WHERE id = ?', [$topicId]);
    if ($topic === null || topic_close_if_due($topic) !== 'active') {
        throw new DomainException('flash.topic_not_votable');
    }
    $tag = vote_tag($topicId, user_pk($userId));
    $existing = SW::$db->one('SELECT choice, created_at FROM votes WHERE topic_id = ? AND voter_tag = ?', [$topicId, $tag]);
    if ($existing !== null && Clock::nowStr() >= Clock::addHoursStr((string) $existing['created_at'], SW_VOTE_CHANGE_HOURS)) {
        throw new DomainException('flash.vote_locked');
    }
    if ($choice === 'none') {
        SW::$db->run('DELETE FROM votes WHERE topic_id = ? AND voter_tag = ?', [$topicId, $tag]);
        return;
    }
    $now = Clock::nowStr();
    SW::$db->run(
        'INSERT INTO votes (topic_id, voter_tag, choice, created_at, updated_at) VALUES (?, ?, ?, ?, ?)
         ON CONFLICT(topic_id, voter_tag) DO UPDATE SET choice = excluded.choice, updated_at = excluded.updated_at',
        [$topicId, $tag, $choice, $now, $now]
    );
    if ($existing === null) {
        topic_close_if_due(array_merge($topic, ['status' => 'active']));
    }
}
