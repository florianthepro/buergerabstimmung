<?php

// code: https://github.com/florianthepro/v2
// Setzt die Sicherheitskopfzeilen und verteilt die Anfragen.

declare(strict_types=1);

function send_security_headers(): void
{
    header("Content-Security-Policy: default-src 'none'; script-src 'self'; style-src 'self'; "
        . "img-src 'self'; font-src 'self'; connect-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: no-referrer');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=(), usb=()');
    header('Cross-Origin-Opener-Policy: same-origin');
    header('Cross-Origin-Resource-Policy: same-origin');
    header('X-Robots-Tag: noindex');
    if (sw_is_https()) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

function web_main(): void
{
    try {
        sw_setup();
    } catch (Throwable $e) {
        error_log('buergerabstimmung setup: ' . $e->getMessage());
        http_response_code(500);
        header('Content-Type: text/html; charset=utf-8');
        $writable = is_writable(SW_ROOT . '/data') || (!is_dir(SW_ROOT . '/data') && is_writable(SW_ROOT));
        $hint = $writable
            ? 'Bitte pr&uuml;fen Sie, ob die PHP-Erweiterungen <code>pdo_sqlite</code> und <code>mbstring</code> aktiv sind.'
            : 'Bitte machen Sie das Verzeichnis f&uuml;r PHP beschreibbar (per FTP: Rechte 755 oder 775 f&uuml;r den Ordner der index.php setzen) und laden Sie die Seite neu.';
        echo '<!DOCTYPE html><html lang="de"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
            . '<title>Einrichtung erforderlich</title></head><body style="font-family:sans-serif;max-width:40em;margin:3em auto;padding:0 1em">'
            . '<h1>Fast geschafft</h1><p>Die Anwendung konnte noch nicht starten.</p><p>' . $hint . '</p>'
            . '<p style="color:#666">Details stehen im Server-Fehlerprotokoll.</p></body></html>';
        exit;
    }

    $scriptDir = str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/index.php')));
    $base = rtrim($scriptDir, '/');
    if ($base !== '' && preg_match('#^(/[A-Za-z0-9._~\-]+)+$#', $base) !== 1) {
        $base = '';
    }
    SW::$base = $base;

    $rawPath = (string) (parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH) ?? '/');
    if (preg_match('#(^|/)(data|src)(/|$)#', $rawPath) === 1) {
        http_response_code(404);
        header('Content-Type: text/plain; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        echo "404\n";
        exit;
    }
    $pathInfo = (string) ($_SERVER['PATH_INFO'] ?? '');
    if ($pathInfo !== '' && $pathInfo[0] === '/') {
        $path = $pathInfo;
    } else {
        $path = $rawPath;
        if (SW::$base !== '' && strpos($path, SW::$base) === 0) {
            $path = substr($path, strlen(SW::$base));
        }
        if (strpos($path, '/index.php') === 0) {
            $path = substr($path, strlen('/index.php'));
        }
    }
    SW::$path = $path === '' ? '/' : $path;
    $path = SW::$path;

    $method0 = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
    if (($method0 === 'GET' || $method0 === 'HEAD') && strpos($rawPath, '/index.php') !== false) {
        $qs = (string) ($_SERVER['QUERY_STRING'] ?? '');
        header('Location: ' . (base_path() . $path) . ($qs !== '' ? '?' . $qs : ''), true, 301);
        exit;
    }

    if (preg_match('#^/a/(app\.css|app\.js|icon\.svg)$#', $path, $m) === 1) {
        $kindMap = ['app.css' => 'css', 'app.js' => 'js', 'icon.svg' => 'icon'];
        serve_asset($kindMap[$m[1]]);
    }
    if ($path === '/robots.txt') {
        header('Content-Type: text/plain; charset=utf-8');
        echo "User-agent: *\nDisallow: /\n";
        exit;
    }

    if (preg_match('#^/(favicon\.ico|favicon\.png|apple-touch-icon(?:-precomposed)?\.png|icon-192\.png)$#', $path, $mIcon) === 1) {
        $name = $mIcon[1];
        header('Cache-Control: public, max-age=86400');
        header('X-Content-Type-Options: nosniff');
        if ($name === 'favicon.ico') {
            header('Content-Type: image/x-icon');
            echo icon_ico(32);
        } else {
            $size = $name === 'favicon.png' ? 32 : ($name === 'icon-192.png' ? 192 : 180);
            header('Content-Type: image/png');
            echo icon_png($size);
        }
        exit;
    }

    if ($path === '/server.pub') {
        header('Content-Type: text/plain; charset=utf-8');
        echo server_sign_pk_hex() . "\n";
        exit;
    }

    send_security_headers();
    session_boot();

    $user = auth_user();
    $lang = is_string($_SESSION['lang'] ?? null) ? (string) $_SESSION['lang'] : '';
    if ($lang === '' && !consent_given()) {
        $lang = lang_from_request();
    }
    if (!in_array($lang, (array) SW::$cfg['langs'], true)) {
        $lang = (string) SW::$cfg['default_lang'];
    }
    SW::$lang = $lang;
    SW::$tActive = $lang === 'en' ? SW_EN : SW_DE;

    $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));

    try {
        maintenance_tick_throttled();

        if (!in_array($method, ['GET', 'HEAD', 'POST'], true)) {
            v_error(405, 'error.method');
        }

        $reading = $method === 'GET' || $method === 'HEAD';
        if ($path === '/consent' && $reading) {
            consent_set();
            redirect(consent_return());
        }

        $public = $path === '/' || preg_match('#^/topic/\d{1,10}$#', $path) === 1
            || in_array($path, ['/auth', '/imprint', '/privacy', '/api/topics'], true);
        if (!consent_given() && !($reading && $public)) {
            v_error(403, 'error.consent');
        }

        $langChosen = !consent_given() || is_string($_SESSION['lang'] ?? null) || $user !== null;
        if (!$langChosen && $reading
            && !in_array($path, ['/start', '/imprint', '/privacy'], true)
            && strpos($path, '/eid/') !== 0
            && strpos($path, '/api/') !== 0) {
            redirect('/start?to=' . rawurlencode($path));
        }
        if ($path === '/start' && $reading) {
            if ($langChosen) {
                redirect('/');
            }
            v_start();
        }

        if ($method === 'POST' && !csrf_ok()) {
            log_line('SECURITY', 'csrf_failed', ['path' => $path]);
            flash('error', 'flash.csrf');
            redirect('/');
        }

        if ($user !== null && jury_pending_for((int) $user['id']) !== null) {
            $gateAllowed = ['/jury', '/jury/vote', '/logout', '/lang', '/imprint', '/privacy'];
            if (!in_array($path, $gateAllowed, true)) {
                redirect('/jury');
            }
        }

        $isGet = $method === 'GET' || $method === 'HEAD';

        if ($user === null && $isGet
            && !in_array($path, ['/', '/auth', '/imprint', '/privacy', '/api/topics', '/api/similar'], true)
            && preg_match('#^/topic/\d{1,10}$#', $path) !== 1
            && strpos($path, '/claim/') !== 0
            && strpos($path, '/eid/') !== 0) {
            redirect('/auth');
        }

        if ($path === '/' && $isGet) {
            v_main();
        }
        if (($path === '/topics' || $path === '/topics/new' || $path === '/me') && $isGet) {
            redirect('/');
        }
        if ($path === '/topics' && $method === 'POST') {
            h_topic_create();
        }
        if (preg_match('#^/topic/(\d{1,10})$#', $path, $m) === 1 && $isGet) {
            v_topic((int) $m[1]);
        }
        if (preg_match('#^/topic/(\d{1,10})/edit$#', $path, $m) === 1 && $isGet) {
            v_topic_edit((int) $m[1]);
        }
        if (preg_match('#^/topic/(\d{1,10})/edit$#', $path, $m) === 1 && $method === 'POST') {
            h_topic_edit((int) $m[1]);
        }
        if (preg_match('#^/topic/(\d{1,10})/archive$#', $path, $m) === 1 && $method === 'POST') {
            h_topic_archive((int) $m[1]);
        }
        if ($path === '/vote' && $method === 'POST') {
            h_vote();
        }
        if ($path === '/favorite' && $method === 'POST') {
            h_favorite();
        }
        if (preg_match('#^/report/(\d{1,10})$#', $path, $m) === 1 && $isGet) {
            v_report((int) $m[1]);
        }
        if ($path === '/report' && $method === 'POST') {
            h_report_create();
        }
        if ($path === '/jury' && $isGet) {
            v_jury();
        }
        if ($path === '/jury/vote' && $method === 'POST') {
            h_jury_vote();
        }
        if ($path === '/profil.yaml' && $isGet) {
            $u = require_user();
            header('Content-Type: text/yaml; charset=utf-8');
            header('Content-Disposition: attachment; filename="profil.yaml"');
            echo profile_sealed($u);
            exit;
        }

        if ($path === '/lang' && $method === 'POST') {
            h_lang();
        }
        if ($path === '/auth' && $isGet) {
            v_auth();
        }
        if (preg_match('#^/claim/([a-f0-9]{16,64})$#', $path, $m) === 1 && $isGet) {
            h_claim($m[1]);
        }
        if ($path === '/eid/start' && $isGet) {
            h_eid_start();
        }
        if ($path === '/eid/tctoken' && $isGet) {
            h_eid_tctoken();
        }
        if ($path === '/eid/callback' && $isGet) {
            h_eid_callback();
        }
        if ($path === '/tap' && $method === 'POST') {
            h_tap();
        }
        if ($path === '/card/new' && $method === 'POST') {
            h_card_new();
        }
        if ($path === '/logout' && $method === 'POST') {
            h_logout();
        }
        if ($path === '/api/topics' && $isGet) {
            h_api_topics();
        }
        if ($path === '/api/similar' && $isGet) {
            h_api_similar();
        }
        if ($path === '/setup' && $isGet) {
            v_setup();
        }
        if ($path === '/setup/check' && $method === 'POST') {
            h_setup_check();
        }
        if ($path === '/setup/finish' && $method === 'POST') {
            h_setup_finish();
        }
        if ($path === '/imprint' && $isGet) {
            v_static('imprint.h', ['imprint.p1', 'imprint.p2', 'imprint.p3']);
        }
        if ($path === '/privacy' && $isGet) {
            v_static('privacy.h', ['privacy.p1', 'privacy.p2', 'privacy.p3', 'privacy.p4', 'privacy.p5',
                'privacy.p6', 'privacy.p7', 'privacy.p8', 'privacy.p9', 'privacy.p10']);
        }
        v_error_404();
    } catch (Throwable $e) {
        log_line('ERROR', 'unhandled', ['type' => get_class($e), 'msg' => $e->getMessage(), 'path' => $path]);
        v_error(500, 'error.generic');
    }
}
