<?php

// code: https://github.com/florianthepro/v2
// Hält die Konfiguration, den globalen Zustand und die Zeitrechnung.

declare(strict_types=1);

const SW_CONFIG = [
    'app_name' => 'Bürgerabstimmung', // Name in Titel und Fußzeile
    'domain'   => '', // leer = Host der Anfrage; im Echtbetrieb hier die feste Domain eintragen

    'show_test_banner' => true, // true/false: gelbes Band „Testbetrieb“ ganz oben

    'testmode_end' => 'gui', // gui = Umschalten unter /setup erlaubt, edit = nur hier, live = Testbetrieb sofort beenden

    'eid_mode' => 'demo', // demo = Anmeldung über die Trust-Liste, eid = nur über eigenen eID-Server

    'authorized_keys_url' => '', // https-Adresse der Trust-Liste mit freigegebenen Ausweis-Schlüsseln, leer = keine

    'eid_client_url' => 'http://127.0.0.1:24727/eID-Client', // Ausweis-App auf dem Gerät (BSI TR-03124)

    'eid_server_url'  => '', // https-SOAP-Adresse des eigenen eID-Servers (BSI TR-03130)
    'eid_server_cert' => '', // Pfad zum Client-Zertifikat für den eID-Server
    'eid_server_key'  => '', // Pfad zum privaten Schlüssel dazu
    'eid_providers' => [ // Anmelde-Knöpfe auf /auth; start = https-Startadresse, leer = Knopf meldet „nicht eingerichtet“
        'ausweisapp' => ['label' => 'AusweisApp', 'start' => ''],
        'nect'       => ['label' => 'Nect Wallet', 'start' => ''],
    ],

    'timezone'     => 'Europe/Berlin', // Zeitzone aller angezeigten Daten
    'default_lang' => 'de', // Sprache vor der Auswahl: de oder en
    'langs'        => ['de', 'en'], // wählbare Sprachen

    'jury_share'         => 0.01, // Anteil der Nutzer, der je Meldung ausgelost wird
    'jury_min'           => 5, // angestrebte Mindestgröße der Jury
    'quorum_share'       => 0.005, // Anteil der Nutzer, der für eine gültige Entscheidung stimmen muss
    'quorum_min'         => 3, // angestrebte Mindestzahl abgegebener Jurystimmen
    'report_vote_hours'  => 24, // Stunden, die eine Jury zum Entscheiden hat
    'jury_cooldown_days' => 3, // Tage, die jemand nach einem Dienst nicht erneut gelost wird
    'reports_per_day'    => 3, // Meldungen, die eine Person pro Tag abgeben darf

    'session_idle_minutes' => 30, // Minuten ohne Aufruf bis zur Abmeldung
    'session_max_hours'    => 8, // Stunden bis zur Abmeldung, auch bei Betrieb

    'page_size' => 20, // Themen je Seite
];

final class SW
{
    public static array $cfg = SW_CONFIG;
    public static ?Db $db = null;
    public static string $dataDir = '';
    public static string $pepper = '';
    public static string $serverSign = '';
    public static ?bool $testMode = null;
    public static string $lang = 'de';

    public static array $tActive = [];
    public static ?array $user = null;
    public static string $base = '';
    public static string $path = '/';
}

final class Clock
{
    public const FORMAT = 'Y-m-d H:i:s';
    private static ?DateTimeImmutable $testNow = null;
    private static string $tz = 'Europe/Berlin';

    public static function setTimezone(string $tz): void
    {
        self::$tz = $tz;
    }

    public static function setTestNow(?DateTimeImmutable $now): void
    {
        self::$testNow = $now === null ? null : $now->setTimezone(new DateTimeZone('UTC'));
    }

    public static function now(): DateTimeImmutable
    {
        return self::$testNow ?? new DateTimeImmutable('now', new DateTimeZone('UTC'));
    }

    public static function nowStr(): string
    {
        return self::now()->format(self::FORMAT);
    }

    public static function localDate(): string
    {
        return self::now()->setTimezone(new DateTimeZone(self::$tz))->format('Y-m-d');
    }

    public static function nextLocalMidnightUtcStr(): string
    {
        $local = self::now()->setTimezone(new DateTimeZone(self::$tz));
        return $local->modify('tomorrow')->setTime(0, 0, 0)
            ->setTimezone(new DateTimeZone('UTC'))->format(self::FORMAT);
    }

    public static function addHoursStr(string $utc, int $hours): string
    {
        return self::fromStr($utc)->modify(sprintf('%+d hours', $hours))->format(self::FORMAT);
    }

    public static function addDaysStr(string $utc, int $days): string
    {
        return self::fromStr($utc)->modify(sprintf('%+d days', $days))->format(self::FORMAT);
    }

    public static function fromStr(string $utc): DateTimeImmutable
    {
        return new DateTimeImmutable($utc, new DateTimeZone('UTC'));
    }

    public static function displayLocal(string $utc, string $format): string
    {
        return self::fromStr($utc)->setTimezone(new DateTimeZone(self::$tz))->format($format);
    }
}
