<?php

// code: https://github.com/florianthepro/v2
// Liefert Stylesheet, Skript und Symbole aus.

declare(strict_types=1);

function asset_source(string $kind): string
{
    $files = ['css' => 'app.css', 'js' => 'app.js', 'icon' => 'icon.svg'];
    if (!isset($files[$kind])) {
        return '';
    }
    $body = @file_get_contents(SW_ROOT . '/src/assets/' . $files[$kind]);
    return $body === false ? '' : $body;
}

function serve_asset(string $kind): void
{
    $map = [
        'css'  => ['text/css; charset=utf-8', asset_source('css')],
        'js'   => ['text/javascript; charset=utf-8', asset_source('js')],
        'icon' => ['image/svg+xml', asset_source('icon')],
    ];
    if (!isset($map[$kind])) {
        http_response_code(404);
        exit;
    }
    header('Content-Type: ' . $map[$kind][0]);
    header('Cache-Control: public, max-age=3600');
    header('X-Content-Type-Options: nosniff');
    echo $map[$kind][1];
    if ($kind === 'css') {

        for ($i = 0; $i <= 100; $i++) {
            echo "\n.w-" . $i . ' { flex-grow: ' . $i . '; }';
        }
    }
    exit;
}

function flag_de(): string
{
    return '<svg class="flag" viewBox="0 0 60 36" aria-hidden="true" focusable="false">'
        . '<rect width="60" height="12" y="0" fill="#000000"/>'
        . '<rect width="60" height="12" y="12" fill="#dd0000"/>'
        . '<rect width="60" height="12" y="24" fill="#ffcc00"/></svg>';
}

function flag_en(): string
{
    return '<svg class="flag" viewBox="0 0 60 36" aria-hidden="true" focusable="false">'
        . '<rect width="60" height="36" fill="#012169"/>'
        . '<path d="M0 0L60 36M60 0L0 36" stroke="#ffffff" stroke-width="7"/>'
        . '<path d="M0 0L60 36M60 0L0 36" stroke="#c8102e" stroke-width="3"/>'
        . '<path d="M30 0V36M0 18H60" stroke="#ffffff" stroke-width="12"/>'
        . '<path d="M30 0V36M0 18H60" stroke="#c8102e" stroke-width="7"/></svg>';
}

function icon_links(): string
{
    return '<link rel="icon" type="image/svg+xml" href="' . e(url('/a/icon.svg')) . '">'
        . '<link rel="icon" type="image/png" sizes="32x32" href="' . e(url('/favicon.png')) . '">'
        . '<link rel="apple-touch-icon" sizes="180x180" href="' . e(url('/apple-touch-icon.png')) . '">';
}

function png_chunk(string $type, string $data): string
{
    return pack('N', strlen($data)) . $type . $data . pack('N', crc32($type . $data));
}

function icon_png(int $size): string
{
    $ss = 3;
    $n = $size * $ss;
    $bg = [17, 17, 17];
    $fg = [255, 255, 255];
    $a1 = [0.265 * $n, 0.515 * $n];
    $b1 = [0.430 * $n, 0.680 * $n];
    $a2 = [0.430 * $n, 0.680 * $n];
    $b2 = [0.735 * $n, 0.340 * $n];
    $half = 0.058 * $n;

    $inBar = static function (float $px, float $py, array $a, array $b, float $half): bool {
        $vx = $b[0] - $a[0];
        $vy = $b[1] - $a[1];
        $len = sqrt($vx * $vx + $vy * $vy);
        if ($len <= 0.0) {
            return false;
        }
        $ux = $vx / $len;
        $uy = $vy / $len;
        $wx = $px - $a[0];
        $wy = $py - $a[1];
        $along = $wx * $ux + $wy * $uy;
        $perp = abs($wx * -$uy + $wy * $ux);
        return $perp <= $half && $along >= -$half && $along <= $len + $half;
    };

    $raw = '';
    for ($y = 0; $y < $size; $y++) {
        $raw .= "\x00";
        for ($x = 0; $x < $size; $x++) {
            $rSum = 0; $gSum = 0; $bSum = 0;
            for ($sy = 0; $sy < $ss; $sy++) {
                for ($sx = 0; $sx < $ss; $sx++) {
                    $px = $x * $ss + $sx + 0.5;
                    $py = $y * $ss + $sy + 0.5;
                    $on = $inBar($px, $py, $a1, $b1, $half) || $inBar($px, $py, $a2, $b2, $half);
                    $col = $on ? $fg : $bg;
                    $rSum += $col[0]; $gSum += $col[1]; $bSum += $col[2];
                }
            }
            $total = $ss * $ss;
            $raw .= chr((int) round($rSum / $total)) . chr((int) round($gSum / $total))
                . chr((int) round($bSum / $total)) . chr(255);
        }
    }
    $ihdr = pack('NN', $size, $size) . chr(8) . chr(6) . chr(0) . chr(0) . chr(0);
    return "\x89PNG\r\n\x1a\n"
        . png_chunk('IHDR', $ihdr)
        . png_chunk('IDAT', gzcompress($raw, 9))
        . png_chunk('IEND', '');
}

function icon_ico(int $size = 32): string
{
    $png = icon_png($size);
    $dim = $size >= 256 ? 0 : $size;
    return pack('vvv', 0, 1, 1)
        . chr($dim) . chr($dim) . chr(0) . chr(0)
        . pack('vv', 1, 32)
        . pack('VV', strlen($png), 22)
        . $png;
}

function icon_cookie(): string
{
    return '<svg class="tap-icon" viewBox="0 0 48 48" aria-hidden="true" focusable="false">'
        . '<path d="M24 5a19 19 0 1 0 19 19 8 8 0 0 1-9.5-9.5A8 8 0 0 1 24 5Z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/>'
        . '<circle cx="18" cy="19" r="2.4" fill="currentColor"/>'
        . '<circle cx="16" cy="30" r="2.4" fill="currentColor"/>'
        . '<circle cx="27" cy="33" r="2.4" fill="currentColor"/>'
        . '<circle cx="29" cy="24" r="2" fill="currentColor"/>'
        . '</svg>';
}

function icon_bookmark(bool $filled): string
{
    return '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false">'
        . '<path d="M6.5 3h11a1 1 0 0 1 1 1v17l-6.5-4.4L5.5 21V4a1 1 0 0 1 1-1z"'
        . ' fill="' . ($filled ? 'currentColor' : 'none') . '" stroke="currentColor"'
        . ' stroke-width="1.9" stroke-linejoin="round"/></svg>';
}

function icon_archive(): string
{
    return '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false">'
        . '<rect x="3" y="4" width="18" height="4.5" rx="1" fill="none" stroke="currentColor" stroke-width="1.9"/>'
        . '<path d="M5 8.5v10.2a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1V8.5" fill="none" stroke="currentColor"'
        . ' stroke-width="1.9" stroke-linejoin="round"/>'
        . '<line x1="9.75" y1="12.4" x2="14.25" y2="12.4" stroke="currentColor" stroke-width="1.9"'
        . ' stroke-linecap="round"/></svg>';
}

function icon_flag(): string
{
    return '<svg class="ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false">'
        . '<path d="M6 21V4" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"/>'
        . '<path d="M6 4.6h11.6l-2.5 4.2 2.5 4.2H6z" fill="currentColor" stroke="currentColor"'
        . ' stroke-width="1.4" stroke-linejoin="round"/></svg>';
}
