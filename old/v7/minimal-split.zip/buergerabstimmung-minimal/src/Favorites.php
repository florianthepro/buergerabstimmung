<?php

// code: https://github.com/florianthepro/v2
// Speichert Lesezeichen auf Themen, Kategorien und Gebiete.

declare(strict_types=1);

function fav_to_gebiet(string $ref): ?string
{
    if ($ref === 'bund') {
        return 'de';
    }
    $parts = explode(':', $ref, 2);
    if (count($parts) !== 2) {
        return null;
    }
    if ($parts[0] === 'bundesland' && isset(SW_REGIONS[$parts[1]])) {
        return 'bl:' . $parts[1];
    }
    if ($parts[0] === 'landkreis') {
        foreach (SW_REGIONS as $land => $kreise) {
            if (in_array($parts[1], $kreise, true)) {
                return 'kr:' . $land . ':' . $parts[1];
            }
        }
    }
    return null;
}

function fav_valid(string $kind, string $ref): bool
{
    if ($kind === 'topic') {
        return preg_match('/^\d{1,10}$/', $ref) === 1
            && null !== SW::$db->one('SELECT 1 FROM topics WHERE id = ?', [(int) $ref]);
    }
    if ($kind === 'category') {
        return null !== SW::$db->one('SELECT 1 FROM categories WHERE slug = ?', [$ref]);
    }
    if ($kind === 'scope') {
        if ($ref === 'bund') {
            return true;
        }
        $parts = explode(':', $ref, 2);
        if (count($parts) !== 2) {
            return false;
        }
        if ($parts[0] === 'bundesland') {
            return isset(SW_REGIONS[$parts[1]]);
        }
        if ($parts[0] === 'landkreis') {
            foreach (SW_REGIONS as $kreise) {
                if (in_array($parts[1], $kreise, true)) {
                    return true;
                }
            }
        }
        return false;
    }
    return false;
}

function fav_toggle(int $userId, string $kind, string $ref): bool
{
    if (!fav_valid($kind, $ref)) {
        throw new DomainException('flash.invalid_input');
    }
    $exists = SW::$db->one('SELECT 1 FROM favorites WHERE user_id = ? AND kind = ? AND ref = ?', [$userId, $kind, $ref]);
    if ($exists !== null) {
        SW::$db->run('DELETE FROM favorites WHERE user_id = ? AND kind = ? AND ref = ?', [$userId, $kind, $ref]);
        return false;
    }
    SW::$db->run(
        'INSERT INTO favorites (user_id, kind, ref, created_at) VALUES (?, ?, ?, ?)',
        [$userId, $kind, $ref, Clock::nowStr()]
    );
    return true;
}

function fav_is(int $userId, string $kind, string $ref): bool
{
    return null !== SW::$db->one('SELECT 1 FROM favorites WHERE user_id = ? AND kind = ? AND ref = ?', [$userId, $kind, $ref]);
}

function fav_list(int $userId): array
{
    return SW::$db->all(
        'SELECT f.kind, f.ref, c.name_de, c.name_en, t.title AS topic_title, t.status AS topic_status
         FROM favorites f
         LEFT JOIN categories c ON f.kind = \'category\' AND c.slug = f.ref
         LEFT JOIN topics t ON f.kind = \'topic\' AND t.id = CAST(f.ref AS INTEGER)
         WHERE f.user_id = ?
         ORDER BY f.kind, f.ref',
        [$userId]
    );
}
