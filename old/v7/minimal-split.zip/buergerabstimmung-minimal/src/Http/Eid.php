<?php

// code: https://github.com/florianthepro/v2
// Bindet eID-Client und eID-Server an.

declare(strict_types=1);

function h_eid_start(): void
{
    $key = query_str('provider', 30);
    $providers = (array) SW::$cfg['eid_providers'];
    if (!isset($providers[$key])) {
        flash('error', 'flash.eid_required');
        redirect('/auth');
    }
    if (!rate_allow('eid:' . ip_key(), 20, 600)) {
        flash('error', 'flash.rate_limited');
        redirect('/auth');
    }
    if ($key === 'ausweisapp') {

        $nonce = bin2hex(random_bytes(16));
        eid_flow_start($nonce);
        $tcToken = site_url('/eid/tctoken?s=' . $nonce);
        $client = (string) SW::$cfg['eid_client_url'];
        log_line('SECURITY', 'eid_client_activation', ['provider' => 'ausweisapp']);
        header('Location: ' . $client . '?tcTokenURL=' . rawurlencode($tcToken), true, 303);
        exit;
    }
    $start = (string) ($providers[$key]['start'] ?? '');
    if ($start === '' || preg_match('#^https://#', $start) !== 1) {

        flash('error', 'flash.eid_provider_off');
        redirect('/auth');
    }

    $sep = strpos($start, '?') === false ? '?' : '&';
    header('Location: ' . $start . $sep . 'redirect=' . rawurlencode(site_url('/eid/callback')), true, 303);
    exit;
}

function h_eid_tctoken(): void
{
    header('Content-Type: text/xml; charset=utf-8');
    header('Cache-Control: no-store');
    $nonce = query_str('s', 40);
    $errorUrl = site_url('/eid/callback?e=1');
    $flow = eid_flow_find($nonce);
    if ($flow === null) {
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n"
            . '<TCTokenType><CommunicationErrorAddress>' . e($errorUrl)
            . '</CommunicationErrorAddress></TCTokenType>';
        exit;
    }
    $session = eid_server_useid();
    if ($session === null) {

        log_line('SECURITY', 'eid_tctoken_unconfigured', []);
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n"
            . '<TCTokenType><CommunicationErrorAddress>' . e($errorUrl)
            . '</CommunicationErrorAddress></TCTokenType>';
        exit;
    }
    eid_flow_bind($nonce, $session['session']);
    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n"
        . '<TCTokenType>'
        . '<ServerAddress>' . e($session['paos']) . '</ServerAddress>'
        . '<SessionIdentifier>' . e($session['session']) . '</SessionIdentifier>'
        . '<RefreshAddress>' . e(site_url('/eid/callback')) . '</RefreshAddress>'
        . '<CommunicationErrorAddress>' . e($errorUrl) . '</CommunicationErrorAddress>'
        . '<Binding>urn:liberty:paos:2006-08</Binding>'
        . '</TCTokenType>';
    exit;
}

function eid_flow_start(string $nonce): void
{
    SW::$db->run('DELETE FROM eid_flows WHERE created_at < ?', [Clock::now()->getTimestamp() - 600]);
    SW::$db->run(
        'INSERT INTO eid_flows (nonce, session_id, created_at) VALUES (?, ?, ?)',
        [$nonce, session_id(), Clock::now()->getTimestamp()]
    );
}

function eid_flow_find(string $nonce): ?array
{
    if (preg_match('/^[a-f0-9]{32}$/', $nonce) !== 1) {
        return null;
    }
    $row = SW::$db->one('SELECT * FROM eid_flows WHERE nonce = ?', [$nonce]);
    if ($row === null || (int) $row['created_at'] < Clock::now()->getTimestamp() - 600) {
        return null;
    }
    return $row;
}

function eid_flow_bind(string $nonce, string $ref): void
{
    SW::$db->run('UPDATE eid_flows SET eid_ref = ? WHERE nonce = ?', [$ref, $nonce]);
}

function eid_server_useid(?array $over = null): ?array
{
    $cfg = $over ?? SW::$cfg;
    $url = (string) ($cfg['eid_server_url'] ?? '');
    if ($url === '' || preg_match('#^https://#', $url) !== 1) {
        return null;
    }
    $soap = '<?xml version="1.0" encoding="UTF-8"?>'
        . '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"'
        . ' xmlns:eid="http://bsi.bund.de/eID/"><soap:Body><eid:useIDRequest>'
        . '<eid:UseOperations><eid:RestrictedIdentification eid:required="REQUIRED"/></eid:UseOperations>'
        . '</eid:useIDRequest></soap:Body></soap:Envelope>';
    $ctx = ['http' => [
        'method'  => 'POST',
        'header'  => "Content-Type: text/xml; charset=utf-8\r\nSOAPAction: \"\"\r\n",
        'content' => $soap,
        'timeout' => 8,
        'ignore_errors' => true,
    ], 'ssl' => ['verify_peer' => true, 'verify_peer_name' => true]];
    if ((string) ($cfg['eid_server_cert'] ?? '') !== '') {
        $ctx['ssl']['local_cert'] = (string) $cfg['eid_server_cert'];
    }
    if ((string) ($cfg['eid_server_key'] ?? '') !== '') {
        $ctx['ssl']['local_pk'] = (string) $cfg['eid_server_key'];
    }
    $xml = @file_get_contents($url, false, stream_context_create($ctx));
    if (!is_string($xml) || $xml === '') {
        log_line('SECURITY', 'eid_server_unreachable', []);
        return null;
    }
    $paos = eid_xml_value($xml, 'eCardServerAddress');
    $session = eid_xml_value($xml, 'Session');
    if ($session === '') {
        $session = eid_xml_value($xml, 'ID');
    }
    if ($paos === '' || $session === '') {
        log_line('SECURITY', 'eid_server_bad_response', []);
        return null;
    }
    return ['paos' => $paos, 'session' => $session];
}

function eid_xml_value(string $xml, string $name): string
{
    $pattern = '#<(?:[A-Za-z0-9_.-]+:)?' . preg_quote($name, '#') . '(?:\s[^>]*)?>([^<]*)</#';
    return preg_match($pattern, $xml, $m) === 1 ? trim(html_entity_decode($m[1], ENT_QUOTES, 'UTF-8')) : '';
}

function h_eid_callback(): void
{
    $flow = SW::$db->one(
        'SELECT * FROM eid_flows WHERE session_id = ? ORDER BY created_at DESC LIMIT 1',
        [session_id()]
    );
    SW::$db->run('DELETE FROM eid_flows WHERE session_id = ?', [session_id()]);
    if ($flow === null || ($flow['eid_ref'] ?? '') === '' || query_str('e', 4) !== '') {
        flash('error', 'flash.eid_required');
        redirect('/auth');
    }

    log_line('SECURITY', 'eid_callback_unverified', []);
    flash('error', 'flash.eid_required');
    redirect('/auth');
}
