<?php

// code: https://github.com/florianthepro/v2
// Verarbeitet die abgeschickten Formulare.

declare(strict_types=1);

function h_setup_check(): void
{
    require_user();
    if (!test_mode()) {
        redirect('/');
    }
    if (!rate_allow('setup:' . ip_key(), 20, 600)) {
        flash('error', 'flash.rate_limited');
        redirect('/setup');
    }
    [$errors, $values] = setup_validate(setup_read_post());
    $errors = array_values(array_filter($errors, static function (string $key): bool {
        return $key !== 'setup.err_list_empty';
    }));
    if ($errors !== []) {
        v_setup($errors, $values);
    }
    unset($_SESSION['setup_check']);
    if ($values['eid_mode'] === 'eid') {
        if ($values['eid_server_url'] === '') {
            flash('info', 'flash.setup_no_server');
            v_setup([], $values);
        }
        $ok = setup_probe($values);
        flash($ok ? 'success' : 'error', $ok ? 'flash.setup_ok' : 'flash.setup_failed');
    } else {
        $count = setup_probe_list((string) $values['authorized_keys_url']);
        $ok = $count !== null && $count > 0;
        if ($count === null) {
            flash('error', 'flash.setup_list_failed');
        } elseif ($count === 0) {
            flash('error', 'setup.err_list_empty');
        } else {
            flash('success', 'flash.setup_list_ok', ['n' => num($count)]);
        }
    }
    if ($ok) {
        $_SESSION['setup_check'] = setup_check_stamp($values);
    }
    v_setup([], $values);
}

function h_setup_finish(): void
{
    require_user();
    if (!test_mode()) {
        redirect('/');
    }
    if ((string) SW::$cfg['testmode_end'] !== 'gui') {
        redirect('/setup');
    }
    if (!rate_allow('setup:' . ip_key(), 20, 600)) {
        flash('error', 'flash.rate_limited');
        redirect('/setup');
    }
    [$errors, $values] = setup_validate(setup_read_post());
    if (post_str('confirm', 10) !== 'yes') {
        $errors[] = 'flash.testmode_confirm';
    }
    $token = setup_token();
    if ($token === '' || !hash_equals($token, post_str('token', 80))) {
        log_line('SECURITY', 'setup_token_bad', []);
        $errors[] = 'setup.err_token';
    }
    if (!setup_checked($values)) {
        $errors[] = 'setup.err_check_first';
    }
    if ($errors !== []) {
        v_setup(array_values(array_unique($errors)), $values);
    }
    if (!setup_save($values)) {
        v_setup(['setup.err_save'], $values);
    }
    setup_apply($values);
    test_mode_end();
    unset($_SESSION['setup_check']);
    @unlink(setup_token_file());
    auth_logout();
    card_forget();
    flash('info', 'flash.testmode_ended');
    redirect('/auth');
}

function h_tap(): void
{
    if (!rate_allow('auth:' . ip_key(), 10, 600)) {
        flash('error', 'flash.rate_limited');
        redirect('/auth');
    }
    if (test_mode()) {

        $card = card_create();
        authorized_add([card_identity($card)], 'test-login');
        test_key_add(card_identity($card));
    } else {

        if ((string) SW::$cfg['eid_mode'] === 'eid') {
            log_line('SECURITY', 'eid_not_configured', []);
            flash('error', 'flash.eid_required');
            redirect('/auth');
        }

        $card = card_load();
        if ($card === null) {
            flash('error', 'flash.no_card');
            redirect('/auth');
        }
    }

    $identity = card_identity($card);
    $sealed = card_seal($card, 'login:' . $identity);
    if (!card_open($card['pk'], $sealed, 'login:' . $identity)) {
        log_line('SECURITY', 'card_verify_failed', []);
        flash('error', 'flash.auth_failed');
        redirect('/auth');
    }

    if (!authorized_contains($identity)) {
        log_line('SECURITY', 'card_not_authorized', []);
        card_forget();
        flash('error', 'flash.card_not_authorized');
        redirect('/auth');
    }
    auth_login($identity);
    $_SESSION['auth_slot'] = time_slot();
    redirect('/');
}

function h_claim(string $handle): void
{
    if ((string) SW::$cfg['eid_mode'] === 'eid') {
        redirect('/auth');
    }
    if (preg_match('/^[a-f0-9]{16,64}$/', $handle) !== 1) {
        flash('error', 'flash.no_card');
        redirect('/auth');
    }
    $file = SW::$dataDir . '/issued/' . $handle . '.key';
    if (!is_file($file)) {
        flash('error', 'flash.no_card');
        redirect('/auth');
    }
    $secret = base64_decode(trim((string) file_get_contents($file)), true);
    if ($secret === false) {
        flash('error', 'flash.no_card');
        redirect('/auth');
    }
    $_SESSION['card'] = base64_encode($secret);
    flash('info', 'flash.card_ready');
    redirect('/auth');
}

function h_card_new(): void
{
    auth_logout();
    card_forget();
    flash('info', 'flash.card_new');
    redirect('/auth');
}

function h_logout(): void
{
    SW::$user = null;
    session_forget();
    redirect('/');
}

function h_vote(): void
{
    $user = require_user();
    require_card($user);
    $topicId = post_int('topic_id');
    $choice = post_str('choice', 10);
    if ($topicId === null) {
        redirect('/topics');
    }
    $back = '/topic/' . $topicId;
    if (!rate_allow('vote:' . (int) $user['id'], 60, 600)) {
        flash('error', 'flash.rate_limited');
        redirect($back);
    }
    try {
        vote_cast((int) $user['id'], $topicId, $choice);
    } catch (DomainException $e) {
        flash('error', $e->getMessage());
        redirect($back);
    }
    flash('success', $choice === 'none' ? 'flash.vote_withdrawn' : 'flash.vote_saved');
    redirect($back);
}

function h_topic_create(): void
{
    $user = require_user();
    require_card($user);
    $userId = (int) $user['id'];
    if (!rate_allow('topic-form:' . $userId, 10, 600)) {
        flash('error', 'flash.rate_limited');
        redirect('/topics/new');
    }
    [$errors, $old, $scope, $end] = topic_form_read();
    if ($errors !== []) {
        v_main($errors, $old);
    }
    try {
        $topicId = topic_create(
            $userId,
            $old['title'],
            $old['goal'],
            $old['reasoning'],
            (int) $old['category_id'],
            $scope[0],
            $scope[1],
            $end[0],
            $end[1],
            $end[2]
        );
    } catch (DomainException $e) {
        v_main([$e->getMessage()], $old);
        return;
    }
    flash('success', 'flash.topic_created');
    redirect('/topic/' . $topicId);
}

function topic_form_read(): array
{
    $old = [
        'title'       => post_str('title', SW_TITLE_MAX),
        'goal'        => post_str('goal', SW_GOAL_MAX, true),
        'reasoning'   => post_str('reasoning', SW_REASONING_MAX, true),
        'category_id' => post_int('category_id') ?? 0,
        'scope'         => post_str('scope', 160),
        'end_by_date'   => isset($_POST['end_by_date']),
        'end_date'      => post_str('end_date', 10),
        'end_by_target' => isset($_POST['end_by_target']),
        'end_value'     => post_str('end_value', 10),
        'end_unit'      => post_str('end_unit', 10),
    ];
    $errors = [];
    if (mb_strlen($old['title']) < SW_TITLE_MIN) {
        $errors[] = 'topic.err_title';
    }
    if (mb_strlen($old['goal']) < SW_GOAL_MIN) {
        $errors[] = 'topic.err_goal';
    }
    if (mb_strlen($old['reasoning']) < SW_REASONING_MIN) {
        $errors[] = 'topic.err_reasoning';
    }
    $category = $old['category_id'] > 0
        ? SW::$db->one('SELECT id FROM categories WHERE id = ?', [$old['category_id']])
        : null;
    if ($category === null) {
        $errors[] = 'topic.err_category';
    }
    $scope = scope_decode($old['scope']);
    if ($scope === null) {
        $errors[] = 'topic.err_scope';
    }
    $end = parse_topic_end();
    if ($end === null) {
        $errors[] = 'topic.err_end';
    }
    return [$errors, $old, $scope, $end];
}

function h_topic_archive(int $topicId): void
{
    $user = require_user();
    require_card($user);
    try {
        topic_archive($topicId, (int) $user['id']);
    } catch (DomainException $e) {
        flash('error', $e->getMessage());
        redirect('/topic/' . $topicId);
    }
    flash('success', 'flash.topic_archived');
    redirect('/topic/' . $topicId);
}

function h_favorite(): void
{
    $user = require_user();
    require_card($user);
    $kind = post_str('kind', 10);
    $ref = post_str('ref', 100);
    $back = safe_return('/topics');
    if (!rate_allow('favorite:' . (int) $user['id'], 60, 600)) {
        flash('error', 'flash.rate_limited');
        redirect($back);
    }
    try {
        $added = fav_toggle((int) $user['id'], $kind, $ref);
    } catch (DomainException $e) {
        flash('error', $e->getMessage());
        redirect($back);
    }
    flash('success', $added ? 'flash.favorite_added' : 'flash.favorite_removed');
    redirect($back);
}

function h_report_create(): void
{
    $user = require_user();
    require_card($user);
    $topicId = post_int('topic_id');
    if ($topicId === null) {
        redirect('/topics');
    }
    if (!rate_allow('report-form:' . (int) $user['id'], 10, 600)) {
        flash('error', 'flash.rate_limited');
        redirect('/report/' . $topicId);
    }
    $lawId = post_str('law', 40);
    if (!isset(SW_LAWS[$lawId])) {
        flash('error', 'flash.report_no_law');
        redirect('/report/' . $topicId);
    }
    try {
        report_create($topicId, (int) $user['id'], $lawId);
    } catch (DomainException $e) {
        flash('error', $e->getMessage());
        redirect('/topic/' . $topicId);
    }
    log_line('SECURITY', 'report_created', ['topic' => $topicId]);
    flash('success', 'flash.report_created');
    redirect('/topic/' . $topicId);
}

function h_jury_vote(): void
{
    $user = require_user();
    require_card($user);
    $reportId = post_int('report_id');
    $vote = post_str('vote', 10);
    if ($reportId === null) {
        redirect('/jury');
    }
    if (!rate_allow('jury:' . (int) $user['id'], 30, 600)) {
        flash('error', 'flash.rate_limited');
        redirect('/jury');
    }
    try {
        jury_cast($reportId, (int) $user['id'], $vote);
    } catch (DomainException $e) {
        flash('error', $e->getMessage());
        redirect('/jury');
    }
    flash('success', 'flash.jury_voted');
    redirect('/jury');
}
