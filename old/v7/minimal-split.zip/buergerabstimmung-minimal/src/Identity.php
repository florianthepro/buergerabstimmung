<?php

// code: https://github.com/florianthepro/v2
// Verwaltet Ausweisschlüssel, Freigabeliste und Anmeldung.

declare(strict_types=1);

function card_supports_sodium(): bool
{
    return function_exists('sodium_crypto_sign_keypair');
}

function authorized_file(): string
{
    return SW::$dataDir . '/authorized_keys.yaml';
}

function authorized_load(): array
{
    $file = authorized_file();
    if (!is_file($file)) {
        return [];
    }
    $set = [];
    foreach (preg_split('/\r?\n/', (string) file_get_contents($file)) as $line) {
        if (preg_match('/["\x27]?([0-9a-fA-F]{64,128})["\x27]?\s*$/', trim($line), $m) === 1
            && strpos(trim($line), '-') === 0) {
            $set[strtolower($m[1])] = true;
        }
    }
    return $set;
}

function authorized_contains(string $pkHex): bool
{
    return isset(authorized_load()[strtolower($pkHex)]);
}

function authorized_count(): int
{
    return count(authorized_load());
}

function test_keys_file(): string
{
    return SW::$dataDir . '/test_keys.list';
}

function test_keys_load(): array
{
    $file = test_keys_file();
    if (!is_file($file)) {
        return [];
    }
    $out = [];
    foreach (preg_split('/\r?\n/', (string) file_get_contents($file)) as $line) {
        $hex = strtolower(trim($line));
        if (preg_match('/^[0-9a-f]{64,128}$/', $hex) === 1) {
            $out[] = $hex;
        }
    }
    return $out;
}

function test_key_add(string $pkHex): void
{
    @file_put_contents(test_keys_file(), strtolower($pkHex) . "\n", FILE_APPEND | LOCK_EX);
    @chmod(test_keys_file(), 0600);
}

function authorized_count_stable(): int
{
    $set = authorized_load();
    foreach (test_keys_load() as $hex) {
        unset($set[$hex]);
    }
    return count($set);
}

function authorized_remove(array $pkHexList): int
{
    $set = authorized_load();
    $removed = 0;
    foreach ($pkHexList as $hex) {
        $hex = strtolower(trim($hex));
        if (isset($set[$hex])) {
            unset($set[$hex]);
            $removed++;
        }
    }
    if ($removed > 0) {
        authorized_write($set, 'cleanup');
    }
    return $removed;
}

function authorized_add(array $pkHexList, string $source): int
{
    $set = authorized_load();
    $added = 0;
    foreach ($pkHexList as $hex) {
        $hex = strtolower(trim($hex));
        if (preg_match('/^[0-9a-f]{64,128}$/', $hex) === 1 && !isset($set[$hex])) {
            $set[$hex] = true;
            $added++;
        }
    }
    authorized_write($set, $source);
    return $added;
}

function authorized_write(array $set, string $source): void
{
    $y = "buergerabstimmung_authorized_keys:\n";
    $y .= "  hinweis: \"Oeffentliche Schluessel autorisierter Ausweise. Nur diese koennen sich anmelden.\"\n";
    $y .= "  aktualisiert: \"" . Clock::nowStr() . "\"\n";
    $y .= "  quelle: \"" . str_replace('"', '', $source) . "\"\n";
    $y .= "  schluessel:\n";
    if ($set === []) {
        $y = substr($y, 0, -1) . " []\n";
    }
    foreach (array_keys($set) as $hex) {
        $y .= "    - \"" . $hex . "\"\n";
    }
    @file_put_contents(authorized_file(), $y, LOCK_EX);
    @chmod(authorized_file(), 0640);
}

function card_load(): ?array
{
    $raw = $_SESSION['card'] ?? '';
    if (!is_string($raw) || $raw === '') {
        return null;
    }
    $secret = base64_decode($raw, true);
    if ($secret === false) {
        return null;
    }
    if (card_supports_sodium()) {
        if (strlen($secret) !== SODIUM_CRYPTO_SIGN_SECRETKEYBYTES) {
            return null;
        }
        return ['secret' => $secret, 'pk' => sodium_crypto_sign_publickey_from_secretkey($secret)];
    }
    if (strlen($secret) !== 32) {
        return null;
    }
    return ['secret' => $secret, 'pk' => hash('sha256', 'pk|' . $secret, true)];
}

function card_create(): array
{
    if (card_supports_sodium()) {
        $pair = sodium_crypto_sign_keypair();
        $secret = sodium_crypto_sign_secretkey($pair);
        $pk = sodium_crypto_sign_publickey($pair);
    } else {
        $secret = random_bytes(32);
        $pk = hash('sha256', 'pk|' . $secret, true);
    }
    $_SESSION['card'] = base64_encode($secret);
    return ['secret' => $secret, 'pk' => $pk];
}

function card_forget(): void
{
    unset($_SESSION['card']);
}

function card_identity(array $card): string
{
    return bin2hex($card['pk']);
}

const SW_SLOT_SECONDS = 300;

const SW_AUTH_SLOTS = 2;

function time_slot(): int
{
    return intdiv(Clock::now()->getTimestamp(), SW_SLOT_SECONDS);
}

function card_seal(array $card, string $action): string
{
    $payload = json_encode(['a' => $action, 'slot' => time_slot(), 'n' => bin2hex(random_bytes(8))]);
    if (card_supports_sodium()) {
        return sodium_crypto_sign($payload, $card['secret']);
    }

    return $payload . '.' . hash('sha256', 'seal|' . $card['pk'] . '|' . $payload);
}

function card_open(string $pk, string $sealed, string $action): bool
{
    if (card_supports_sodium()) {
        $payload = sodium_crypto_sign_open($sealed, $pk);
        if ($payload === false) {
            return false;
        }
    } else {
        $dot = strrpos($sealed, '.');
        if ($dot === false) {
            return false;
        }
        $payload = substr($sealed, 0, $dot);
        $mac = substr($sealed, $dot + 1);
        if (!hash_equals(hash('sha256', 'seal|' . $pk . '|' . $payload), $mac)) {
            return false;
        }
    }
    $data = json_decode($payload, true);
    if (!is_array($data) || ($data['a'] ?? '') !== $action) {
        return false;
    }
    $slot = (int) ($data['slot'] ?? -1);
    $current = time_slot();
    return $slot === $current || $slot === $current - 1;
}

function auth_login(string $pseudonymHash): array
{
    $now = Clock::nowStr();
    $user = SW::$db->one('SELECT * FROM users WHERE pseudonym_hash = ?', [$pseudonymHash]);
    if ($user === null) {
        SW::$db->run(
            'INSERT INTO users (pseudonym_hash, lang, created_at, last_login_at) VALUES (?, ?, ?, ?)',
            [$pseudonymHash, (string) SW::$cfg['default_lang'], $now, $now]
        );
        $user = SW::$db->one('SELECT * FROM users WHERE pseudonym_hash = ?', [$pseudonymHash]);
    } else {
        SW::$db->run('UPDATE users SET last_login_at = ? WHERE id = ?', [$now, (int) $user['id']]);
    }
    session_regenerate_id(true);
    $_SESSION['user_id'] = (int) $user['id'];
    $_SESSION['auth_time'] = time();
    SW::$user = $user;
    return $user;
}

function auth_logout(): void
{
    unset($_SESSION['user_id'], $_SESSION['auth_time']);
    session_regenerate_id(true);
    SW::$user = null;
}

function auth_user(): ?array
{
    if (SW::$user !== null) {
        return SW::$user;
    }
    $id = $_SESSION['user_id'] ?? null;
    if (!is_int($id)) {
        return null;
    }

    $slot = $_SESSION['auth_slot'] ?? null;
    if (!test_mode() && is_int($slot) && (time_slot() - $slot) >= SW_AUTH_SLOTS) {
        unset($_SESSION['user_id'], $_SESSION['auth_time'], $_SESSION['auth_slot']);
        card_forget();
        session_regenerate_id(true);
        flash('info', 'flash.auth_expired');
        return null;
    }
    SW::$user = SW::$db->one('SELECT * FROM users WHERE id = ? AND is_system = 0', [$id]);
    return SW::$user;
}

function require_user(): array
{
    $user = auth_user();
    if ($user === null) {
        flash('info', 'flash.login_required');
        redirect('/auth');
    }
    return $user;
}

function card_confirm_ok(array $user, ?array $card, string $action): bool
{
    if (test_mode()) {
        return true;
    }
    if ($card === null) {
        return false;
    }
    if (!hash_equals((string) $user['pseudonym_hash'], card_identity($card))) {
        return false;
    }
    return card_open($card['pk'], card_seal($card, $action), $action);
}

function require_card(array $user): void
{
    $action = 'confirm:' . SW::$path;
    if (!card_confirm_ok($user, card_load(), $action)) {
        log_line('SECURITY', 'card_confirm_failed', []);
        flash('error', 'flash.card_required');
        redirect('/auth');
    }
}

function short_id(array $user): string
{
    return strtoupper(substr((string) $user['pseudonym_hash'], 0, 8));
}
