<?php

// code: https://github.com/florianthepro/v2
// Zeigt Startseite, Anmeldung und die verschlüsselte Profildatei.

declare(strict_types=1);

function v_start(): void
{
    http_response_code(200);
    $to = consent_return();
    $banner = empty(SW::$cfg['show_official_banner'])
        ? ''
        : '<div class="test-banner" role="note">' . e(SW_DE['banner.official']) . ' / ' . e(SW_EN['banner.official']) . '</div>';
    echo '<!DOCTYPE html><html lang="de"><head>'
        . '<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<meta name="referrer" content="no-referrer">'
        . '<title>' . e((string) SW::$cfg['app_name']) . '</title>'
        . '<link rel="stylesheet" href="' . e(url('/a/app.css')) . '">'
        . icon_links()
        . '</head><body>' . $banner
        . '<main class="start-gate">'
        . '<p class="start-brand">' . e((string) SW::$cfg['app_name']) . '</p>'
        . '<div class="start-langs">'
        . '<a class="lang-btn" lang="de" href="' . e(base_path() . '/lang?set=de&to=' . rawurlencode($to)) . '">'
        . flag_de() . '<span>Deutsch</span></a>'
        . '<a class="lang-btn" lang="en" href="' . e(base_path() . '/lang?set=en&to=' . rawurlencode($to)) . '">'
        . flag_en() . '<span>English</span></a>'
        . '</div></main></body></html>';
    exit;
}

function v_auth(): void
{
    if (auth_user() !== null) {
        redirect('/me');
    }

    $pictogram = '<svg class="tap-icon" viewBox="0 0 96 64" aria-hidden="true" focusable="false">'
        . '<rect x="4" y="10" width="56" height="38" rx="4" fill="none" stroke="currentColor" stroke-width="3"/>'
        . '<rect x="11" y="19" width="14" height="11" rx="2" fill="currentColor"/>'
        . '<line x1="11" y1="38" x2="46" y2="38" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>'
        . '<path d="M70 18a22 22 0 0 1 0 28" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>'
        . '<path d="M78 12a32 32 0 0 1 0 40" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>'
        . '<path d="M86 6a42 42 0 0 1 0 52" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"/>'
        . '</svg>';
    $mode = (string) SW::$cfg['eid_mode'];
    $card = card_load();
    $ready = $mode !== 'eid' && $card !== null && authorized_contains(card_identity($card));

    if (!consent_given()) {
        render(t('consent.title'), '<section class="card auth-card">' . icon_cookie()
            . '<h1>' . e(t('consent.title')) . '</h1>'
            . '<p class="muted">' . e(t('consent.text')) . '</p>'
            . '<div class="consent-actions">'
            . '<a class="btn btn-primary btn-big" href="' . e(url('/consent?to=/auth')) . '">'
            . e(t('consent.accept')) . '</a></div></section>');
    }

    $html = '<section class="card auth-card">' . $pictogram
        . '<h1>' . e(t('auth.title')) . '</h1>';


    if (test_mode()) {

        $html .= '<form class="auth-action" method="post" action="' . e(url('/tap')) . '">' . csrf_field()
            . '<button type="submit" class="btn btn-primary btn-big">' . e(t('auth.test_login')) . '</button></form>';
    } else {

        $html .= '<div class="provider-list">';
        foreach ((array) SW::$cfg['eid_providers'] as $key => $prov) {
            $html .= '<a class="btn btn-primary provider-btn" href="' . e(url('/eid/start?provider=' . rawurlencode($key))) . '">'
                . e(t('auth.with', ['app' => (string) $prov['label']])) . '</a>';
        }
        $html .= '</div>';
        if ($ready) {

            $html .= '<hr class="hr-soft">'
                . '<form id="tap-form" class="auth-action" method="post" action="' . e(url('/tap')) . '">' . csrf_field()
                . '<button type="submit" class="btn btn-outline btn-big" data-nfc-hide>' . e(t('auth.tap')) . '</button></form>'
                . '<p id="tap-status" class="tap-status" hidden aria-live="polite">' . e(t('auth.hold')) . '</p>';
        }
    }
    $html .= '</section>';
    render(t('auth.title'), $html);
}

function profile_yaml(array $user): string
{
    $userId = (int) $user['id'];
    $y = "buergerabstimmung_profil:\n";
    $y .= "  oeffentlicher_schluessel: " . yq((string) $user['pseudonym_hash']) . "\n";
    $duty = jury_pending_for($userId);
    $upcoming = $duty === null ? jury_upcoming_for($userId) : null;
    $y .= "  jury_aufgabe: " . yq($duty !== null ? 'offen' : ($upcoming !== null ? 'ausgelost' : 'keine')) . "\n";
    $y .= "  stimmen:\n";
    $voted = topics_voted_by($userId);
    if ($voted === []) {
        $y = substr($y, 0, -1) . " []\n";
    }
    foreach ($voted as $row) {
        $y .= "    - thema: " . (int) $row['id'] . "\n";
        $y .= "      titel: " . yq((string) $row['title']) . "\n";
        $y .= "      stimme: " . yq($row['my_choice'] === 'for' ? 'dafuer' : 'dagegen') . "\n";
    }
    $y .= "  eigene_themen:\n";
    $authored = topics_by_author($userId);
    if ($authored === []) {
        $y = substr($y, 0, -1) . " []\n";
    }
    foreach ($authored as $row) {
        $y .= "    - thema: " . (int) $row['id'] . "\n";
        $y .= "      titel: " . yq((string) $row['title']) . "\n";
        $y .= "      status: " . yq((string) $row['status']) . "\n";
    }
    $y .= "  favoriten:\n";
    $favorites = fav_list($userId);
    if ($favorites === []) {
        $y = substr($y, 0, -1) . " []\n";
    }
    foreach ($favorites as $favorite) {
        $art = ['category' => 'kategorie', 'topic' => 'thema'][$favorite['kind']] ?? 'gebiet';
        $y .= "    - art: " . yq($art) . "\n";
        $y .= "      wert: " . yq((string) $favorite['ref']) . "\n";
    }
    $y .= "  meldungen:\n";
    $reports = reports_by($userId);
    if ($reports === []) {
        $y = substr($y, 0, -1) . " []\n";
    }
    foreach ($reports as $report) {
        $y .= "    - thema: " . (int) $report['topic_id'] . "\n";
        $y .= "      status: " . yq((string) $report['status']) . "\n";
    }
    return $y;
}

function server_sign_pk_hex(): string
{
    if (!card_supports_sodium() || SW::$serverSign === '') {
        return '';
    }
    return bin2hex(sodium_crypto_sign_publickey_from_secretkey(SW::$serverSign));
}

function profile_sealed(array $user): string
{
    $plain = profile_yaml($user);
    $pkHex = (string) $user['pseudonym_hash'];
    if (!card_supports_sodium() || SW::$serverSign === '' || strlen(@hex2bin($pkHex) ?: '') !== SODIUM_CRYPTO_SIGN_PUBLICKEYBYTES) {

        $sig = sw_hmac('profil|' . $plain);
        return $plain . "# integritaet(hmac-sha256): " . $sig . "\n";
    }
    $edPk = hex2bin($pkHex);
    $curvePk = sodium_crypto_sign_ed25519_pk_to_curve25519($edPk);
    $cipher = sodium_crypto_box_seal($plain, $curvePk);
    $sig = sodium_crypto_sign_detached($cipher, SW::$serverSign);
    $out = "buergerabstimmung_versiegeltes_profil:\n";
    $out .= "  hinweis: " . yq('An oeffentlichen Ausweis-Schluessel verschluesselt; nur mit dem Ausweis lesbar.') . "\n";
    $out .= "  verschluesselt_fuer: " . yq($pkHex) . "\n";
    $out .= "  server_schluessel: " . yq(server_sign_pk_hex()) . "\n";
    $out .= "  chiffre_b64: " . yq(base64_encode($cipher)) . "\n";
    $out .= "  server_signatur_b64: " . yq(base64_encode($sig)) . "\n";
    return $out;
}
