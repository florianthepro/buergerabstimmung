<?php

// code: https://github.com/florianthepro/v2
// Zeigt die Einrichtungsseite.

declare(strict_types=1);

function v_setup(array $errors = [], ?array $old = null): void
{
    require_user();
    if (!test_mode()) {
        redirect('/');
    }
    $old = $old ?? [
        'eid_mode' => (string) SW::$cfg['eid_mode'],
        'eid_server_url' => (string) SW::$cfg['eid_server_url'],
        'eid_server_cert' => (string) SW::$cfg['eid_server_cert'],
        'eid_server_key' => (string) SW::$cfg['eid_server_key'],
        'eid_client_url' => (string) SW::$cfg['eid_client_url'],
        'authorized_keys_url' => (string) SW::$cfg['authorized_keys_url'],
        'nect_start' => (string) (SW::$cfg['eid_providers']['nect']['start'] ?? ''),
    ];
    $html = '<h1>' . e(t('setup.title')) . '</h1>'
        ;
    $missing = array_values(array_filter(setup_ready(), static function (array $row): bool {
        return !$row[1];
    }));
    if ($missing !== []) {
        $html .= '<section class="card"><h2 class="card-h">' . e(t('setup.missing')) . '</h2><ul class="check-list">';
        foreach ($missing as [$key, $ok]) {
            $html .= '<li class="is-warn"><span aria-hidden="true">!</span>' . e(t($key)) . '</li>';
        }
        $html .= '</ul></section>';
    }
    $stable = authorized_count_stable();

    if ($errors !== []) {
        $html .= '<div class="flash flash-error" role="alert"><ul class="plain-list">';
        foreach ($errors as $error) {
            $html .= '<li>' . e(t($error)) . '</li>';
        }
        $html .= '</ul></div>';
    }

    $eid = $old['eid_mode'] === 'eid';
    $html .= '<form class="card form-stack" method="post" action="' . e(url('/setup/finish')) . '">' . csrf_field()
        . '<div class="path-set" role="radiogroup" aria-label="' . e(t('setup.path')) . '">'
        . '<p class="field-label">' . e(t('setup.path')) . '</p>'
        . '<input type="radio" id="path-eid" name="eid_mode" value="eid"' . ($eid ? ' checked' : '') . '>'
        . '<label class="path-label" for="path-eid">' . e(t('setup.path_eid')) . '</label>'
        . '<input type="radio" id="path-list" name="eid_mode" value="demo"' . ($eid ? '' : ' checked') . '>'
        . '<label class="path-label" for="path-list">' . e(t('setup.path_list')) . '</label>'
        . '<div class="form-stack only-eid">'
        . '<label><span>' . e(t('setup.f_server')) . '</span>'
        . '<input type="text" name="eid_server_url" inputmode="url" placeholder="https://…" value="' . e($old['eid_server_url']) . '"></label>'
        . '<label><span>' . e(t('setup.f_cert')) . '</span>'
        . '<input type="text" name="eid_server_cert" value="' . e($old['eid_server_cert']) . '"></label>'
        . '<label><span>' . e(t('setup.f_key')) . '</span>'
        . '<input type="text" name="eid_server_key" value="' . e($old['eid_server_key']) . '"></label>'
        . '<label><span>' . e(t('setup.f_client')) . '</span>'
        . '<input type="text" name="eid_client_url" value="' . e($old['eid_client_url']) . '"></label>'
        . '<label><span>' . e(t('setup.f_nect')) . '</span>'
        . '<input type="text" name="nect_start" inputmode="url" placeholder="https://…" value="' . e($old['nect_start']) . '"></label>'
        . '</div>'
        . '<div class="form-stack only-list">'
        . ($stable > 0 ? '' : '<p class="muted">' . e(t('setup.check_keys')) . '</p>')
        . '<label><span>' . e(t('setup.f_sync')) . '</span>'
        . '<input type="text" name="authorized_keys_url" inputmode="url" placeholder="https://…" value="' . e($old['authorized_keys_url']) . '"></label>'
        . '</div>'
        . '</div>'
        . '<div><button type="submit" class="btn btn-outline" formaction="' . e(url('/setup/check')) . '">'
        . e(t('setup.check_btn')) . '</button></div>';
    if ((string) SW::$cfg['testmode_end'] === 'gui') {
        $html .= '<hr class="hr-soft">'
            . '<label><span>' . e(t('setup.token')) . '</span>'
            . '<input type="text" name="token" autocomplete="off" spellcheck="false"></label>'
            . '<small class="muted">' . e(t('setup.token_hint')) . '</small>'
            . '<label class="check-label"><input type="checkbox" name="confirm" value="yes" required>'
            . '<span>' . e(t('setup.confirm')) . '</span></label>'
            . '<div><button type="submit" class="btn btn-danger btn-big"' . (setup_checked($old) ? '' : ' disabled') . '>'
            . e(t('setup.finish_btn')) . '</button></div>';
    } else {
        $html .= '<hr class="hr-soft"><p class="muted">' . e(t('setup.end_locked')) . '</p>';
    }
    $html .= '</form>';
    render(t('setup.title'), $html);
}
