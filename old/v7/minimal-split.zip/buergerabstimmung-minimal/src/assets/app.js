(function () {
  'use strict';
  var init = function () {

    var nodes = document.querySelectorAll('[data-countdown-to]');
    if (nodes.length > 0) {
      var pad = function (n) { return n < 10 ? '0' + n : String(n); };
      var update = function () {
        nodes.forEach(function (node) {
          var target = Date.parse(node.getAttribute('data-countdown-to').replace(' ', 'T') + 'Z');
          var diff = Math.max(0, Math.floor((target - Date.now()) / 1000));
          var text = pad(Math.floor(diff / 3600)) + ':' + pad(Math.floor((diff % 3600) / 60)) + ':' + pad(diff % 60);
          node.textContent = (node.getAttribute('data-label') || '') + ' ' + text;
        });
      };
      update();
      setInterval(update, 1000);
    }

    document.querySelectorAll('select[data-scope-native]').forEach(function (native) {
      var current = native.value;
      var level = 'de', land = '', kreis = '';
      if (current.indexOf('bl:') === 0) { level = 'bundesland'; land = current.slice(3); }
      else if (current.indexOf('kr:') === 0) { level = 'landkreis'; var r = current.slice(3).split(':'); land = r[0]; kreis = r.slice(1).join(':'); }
      else if (current === '') { level = native.querySelector('option[value=""]') ? 'all' : 'de'; }
      var lands = {}, order = [];
      native.querySelectorAll('optgroup').forEach(function (g) {
        var name = g.label; order.push(name); lands[name] = [];
        g.querySelectorAll('option').forEach(function (o) {
          if (o.value.indexOf('kr:') === 0) { lands[name].push(o.textContent); }
        });
      });
      var L = {
        de: native.getAttribute('data-l-de') || 'DE',
        bl: native.getAttribute('data-l-bl') || 'Bundesland',
        kr: native.getAttribute('data-l-kr') || 'Landkreis',
        pick: native.getAttribute('data-l-pick') || '—',
        all: native.getAttribute('data-l-all') || '—'
      };
      var wrap = document.createElement('div');
      wrap.className = 'scope-picker';
      var hasAll = !!native.querySelector('option[value=""]');
      var selLevel = document.createElement('select');
      if (hasAll) { selLevel.add(new Option(L.all, 'all')); }
      selLevel.add(new Option(L.de, 'de'));
      selLevel.add(new Option(L.bl, 'bundesland'));
      selLevel.add(new Option(L.kr, 'landkreis'));
      selLevel.value = level;
      var selLand = document.createElement('select');
      selLand.add(new Option(L.pick, ''));
      order.forEach(function (n) { selLand.add(new Option(n, n)); });
      if (land) { selLand.value = land; }
      var selKreis = document.createElement('select');
      var fillKreis = function () {
        selKreis.innerHTML = '';
        selKreis.add(new Option(L.pick, ''));
        (lands[selLand.value] || []).forEach(function (k) { selKreis.add(new Option(k, k)); });
        if (kreis) { selKreis.value = kreis; }
      };
      fillKreis();
      var sync = function () {
        var v = 'de';
        if (selLevel.value === 'all') { v = ''; }
        else if (selLevel.value === 'de') { v = 'de'; }
        else if (selLevel.value === 'bundesland') { v = selLand.value ? 'bl:' + selLand.value : ''; }
        else if (selLevel.value === 'landkreis') { v = (selLand.value && selKreis.value) ? 'kr:' + selLand.value + ':' + selKreis.value : ''; }
        native.value = v;
        selLand.hidden = !(selLevel.value === 'bundesland' || selLevel.value === 'landkreis');
        selKreis.hidden = selLevel.value !== 'landkreis';
      };
      selLevel.addEventListener('change', sync);
      selLand.addEventListener('change', function () { kreis = ''; fillKreis(); sync(); });
      selKreis.addEventListener('change', sync);
      native.style.display = 'none';
      native.parentNode.insertBefore(wrap, native);
      wrap.appendChild(selLevel); wrap.appendChild(selLand); wrap.appendChild(selKreis);
      sync();
    });

    document.querySelectorAll('[data-end-fields]').forEach(function (fs) {
      fs.querySelectorAll('[data-end-toggle]').forEach(function (box) {
        var part = fs.querySelector('[data-end-part="' + box.getAttribute('data-end-toggle') + '"]');
        if (!part) return;
        var apply = function () { part.hidden = !box.checked; };
        box.addEventListener('change', apply); apply();
      });
    });

    document.addEventListener('keydown', function (ev) {
      if (ev.key === 'Escape' && location.hash && document.querySelector(location.hash + '.modal')) {
        location.hash = '';
      }
    });

    var base = document.body.getAttribute('data-base') || '';
    var figures = document.querySelectorAll('[data-topic]');
    if (figures.length > 0) {
      var ids = [];
      figures.forEach(function (el) { ids.push(el.getAttribute('data-topic')); });
      var groupSep = document.body.getAttribute('data-group-sep') || '';
      var groupNum = function (n) {
        return groupSep === '' ? String(n) : String(n).replace(/\B(?=(\d{3})+(?!\d))/g, groupSep);
      };
      var setNum = function (el, sel, value) {
        var node = el.querySelector(sel);
        if (node && node.textContent !== value) { node.textContent = value; }
      };
      var refresh = function () {
        fetch(base + '/api/topics?ids=' + encodeURIComponent(ids.join(',')), { credentials: 'same-origin' })
          .then(function (r) { return r.ok ? r.json() : null; })
          .then(function (data) {
            if (!data) { return; }
            figures.forEach(function (el) {
              var row = data[el.getAttribute('data-topic')];
              if (!row) { return; }
              var total = row.f + row.a;
              var pf = total > 0 ? Math.round(row.f * 100 / total) : 0;
              var pa = total > 0 ? 100 - pf : 0;
              var bf = el.querySelector('[data-bar="for"]');
              var ba = el.querySelector('[data-bar="against"]');
              if (bf) { bf.className = 'votebar-for w-' + pf; }
              if (ba) { ba.className = 'votebar-against w-' + pa; }
              setNum(el, '[data-num="for"]', groupNum(row.f));
              setNum(el, '[data-num="against"]', groupNum(row.a));
              setNum(el, '[data-pct="for"]', '/ ' + pf + ' %');
              setNum(el, '[data-pct="against"]', '/ ' + pa + ' %');
            });
          })
          .catch(function () {});
      };
      var timer = setInterval(refresh, 12000);
      document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') { refresh(); }
      });
      window.addEventListener('pagehide', function () { clearInterval(timer); });
    }

    document.querySelectorAll('[data-similar-for]').forEach(function (box) {
      var input = document.querySelector(box.getAttribute('data-similar-for'));
      if (!input) { return; }
      var exclude = box.getAttribute('data-similar-not') || '';
      var wait = null;
      var lookup = function () {
        var q = input.value.trim();
        if (q.length < 6) { box.hidden = true; box.innerHTML = ''; return; }
        fetch(base + '/api/similar?q=' + encodeURIComponent(q) + (exclude ? '&not=' + encodeURIComponent(exclude) : ''),
              { credentials: 'same-origin' })
          .then(function (r) { return r.ok ? r.json() : null; })
          .then(function (rows) {
            if (!rows || rows.length === 0) { box.hidden = true; box.innerHTML = ''; return; }
            var list = document.createElement('ul');
            list.className = 'plain-list';
            rows.forEach(function (row) {
              var li = document.createElement('li');
              var a = document.createElement('a');
              a.href = base + '/topic/' + row.id;
              a.textContent = row.title;
              li.appendChild(a);
              list.appendChild(li);
            });
            var head = document.createElement('p');
            head.className = 'muted';
            head.textContent = box.getAttribute('data-similar-label') || '';
            box.innerHTML = '';
            box.appendChild(head);
            box.appendChild(list);
            box.hidden = false;
          })
          .catch(function () {});
      };
      input.addEventListener('input', function () {
        clearTimeout(wait);
        wait = setTimeout(lookup, 400);
      });
    });

    var profileUrl = document.body.getAttribute('data-profile-url');
    if (profileUrl) {
      fetch(profileUrl, { credentials: 'same-origin' })
        .then(function (r) { return r.ok ? r.text() : null; })
        .then(function (text) {
          try {
            if (text) { sessionStorage.setItem('profil.yaml', text); }
          } catch (e) {}
        })
        .catch(function () {});
    }
    var logoutForms = document.querySelectorAll('form.js-logout');
    logoutForms.forEach(function (form) {
      form.addEventListener('submit', function () {
        try { sessionStorage.removeItem('profil.yaml'); } catch (e) {}
      });
    });

    var tapForm = document.getElementById('tap-form');
    if (tapForm && 'NDEFReader' in window) {
      var status = document.getElementById('tap-status');
      var done = false;
      var go = function () {
        if (!done) { done = true; tapForm.submit(); }
      };
      var startScan = function () {
        var reader = new NDEFReader();
        reader.addEventListener('reading', go);
        reader.addEventListener('readingerror', go);
        return reader.scan();
      };

      try {
        startScan().then(function () {

          if (status) { status.hidden = false; }
          tapForm.querySelectorAll('[data-nfc-hide]').forEach(function (b) { b.hidden = true; });
        }).catch(function () {  });
      } catch (e) {  }

      tapForm.addEventListener('submit', function (ev) {
        if (tapForm.getAttribute('data-armed') === '1') { return; }
        ev.preventDefault();
        tapForm.setAttribute('data-armed', '1');
        if (status) { status.hidden = false; }
        try {
          startScan().catch(go);
        } catch (e) { go(); }
      });
    }
  };
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init); }
  else { init(); }
})();
