<?php

// code: https://github.com/florianthepro/v2
// Lädt alle Module, Grundlagen zuerst und Ausgabe zuletzt.

declare(strict_types=1);

if (!defined('SW_ROOT')) {
    define('SW_ROOT', dirname(__DIR__));
}

require_once SW_ROOT . '/src/Config.php';
require_once SW_ROOT . '/src/Database.php';
require_once SW_ROOT . '/src/Setup.php';
require_once SW_ROOT . '/src/Support.php';
require_once SW_ROOT . '/src/Session.php';
require_once SW_ROOT . '/src/Identity.php';
require_once SW_ROOT . '/src/Topics.php';
require_once SW_ROOT . '/src/Votes.php';
require_once SW_ROOT . '/src/Favorites.php';
require_once SW_ROOT . '/src/Laws.php';
require_once SW_ROOT . '/src/Reports.php';
require_once SW_ROOT . '/src/Maintenance.php';
require_once SW_ROOT . '/src/I18n/de.php';
require_once SW_ROOT . '/src/I18n/en.php';
require_once SW_ROOT . '/src/Assets.php';
require_once SW_ROOT . '/src/View/Layout.php';
require_once SW_ROOT . '/src/View/Topic.php';
require_once SW_ROOT . '/src/View/Account.php';
require_once SW_ROOT . '/src/View/Jury.php';
require_once SW_ROOT . '/src/View/Setup.php';
require_once SW_ROOT . '/src/Http/Eid.php';
require_once SW_ROOT . '/src/Http/Api.php';
require_once SW_ROOT . '/src/Http/Handlers.php';
require_once SW_ROOT . '/src/Http/Router.php';
require_once SW_ROOT . '/src/Cli/Commands.php';
require_once SW_ROOT . '/src/Cli/Selftest.php';
